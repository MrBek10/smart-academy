/*
# Smart Academy — Activity log, Books, Exam results & Cert scoring

1. Yangi jadvallar
- `activity_log`: foydalanuvchi faoliyat tarixi (vaqt, harakat turi, tavsif).
- `books`: admin/yaratuvchi yuklagan elektron kitoblar (PDF, EPUB, ...).
- `exam_results`: har bir imtihon yakuni — ball, Milliy Sertifikat taxminiy balli (1890 ballga nisbatan).

2. Exam scoring (Milliy Sertifikat)
- Har to'g'ri javob uchun 1 ball. Foiz hisoblanadi.
- Taxminiy Milliy Sertifikat balli = foiz * 189 (max 189.0 ball, DTB tizimiga yaqinlashtirilgan).
- Yakuniy va sertifikat bahosi ekran yuzasida ko'rsatiladi.

3. RLS
- activity_log: har foydalanuvchi faqat o'zinikini ko'radi, o'zinikini yozadi.
- books: o'quvchiga SELECT, adminga CRUD.
- exam_results: har foydalanuvchi o'zinikini ko'radi va yozadi.

4. Storage buckets
- `avatars`: profil rasmlari (xususiy, owner folder).
- `test-files`: admin test fayllari (xususiy, signed URL bilan).
- `books`: elektron kitoblar (xususiy, signed URL bilan).
*/

-- ============ ACTIVITY LOG ============
CREATE TABLE IF NOT EXISTS activity_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  action text NOT NULL,
  description text,
  duration_seconds int,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON activity_log TO authenticated;

DROP POLICY IF EXISTS "read_own_log" ON activity_log;
CREATE POLICY "read_own_log" ON activity_log FOR SELECT
  TO authenticated USING (user_id = auth.uid());

DROP POLICY IF EXISTS "insert_own_log" ON activity_log;
CREATE POLICY "insert_own_log" ON activity_log FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid());

-- ============ BOOKS (elektron kitoblar) ============
CREATE TABLE IF NOT EXISTS books (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid REFERENCES subjects(id) ON DELETE SET NULL,
  title text NOT NULL,
  author text,
  description text,
  file_path text NOT NULL,
  file_type text,
  file_size bigint,
  cover_url text,
  uploaded_by uuid NOT NULL REFERENCES profiles(id),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE books ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON books TO authenticated;

DROP POLICY IF EXISTS "read_books" ON books;
CREATE POLICY "read_books" ON books FOR SELECT TO authenticated USING (true);

GRANT INSERT, UPDATE, DELETE ON books TO authenticated;
DROP POLICY IF EXISTS "admin_write_books" ON books;
CREATE POLICY "admin_write_books" ON books FOR ALL
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')));

-- ============ EXAM RESULTS (sertifikat balli) ============
CREATE TABLE IF NOT EXISTS exam_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  exam_id uuid NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  score int NOT NULL,
  total int NOT NULL,
  percent int NOT NULL,
  cert_score numeric(5,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE (user_id, exam_id)
);
ALTER TABLE exam_results ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON exam_results TO authenticated;

DROP POLICY IF EXISTS "read_own_results" ON exam_results;
CREATE POLICY "read_own_results" ON exam_results FOR SELECT
  TO authenticated USING (user_id = auth.uid());

DROP POLICY IF EXISTS "insert_own_results" ON exam_results;
CREATE POLICY "insert_own_results" ON exam_results FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid());

-- ============ STORAGE BUCKETS ============
INSERT INTO storage.buckets (id, name, public) VALUES
  ('avatars', 'avatars', false),
  ('test-files', 'test-files', false),
  ('books', 'books', false)
ON CONFLICT (id) DO NOTHING;

-- avatars: har foydalanuvchi o'z folderiga yozadi
DROP POLICY IF EXISTS "avatars_insert_own" ON storage.objects;
CREATE POLICY "avatars_insert_own" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "avatars_read_own" ON storage.objects;
CREATE POLICY "avatars_read_own" ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "avatars_update_own" ON storage.objects;
CREATE POLICY "avatars_update_own" ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

-- test-files: admin/creator yozadi, hammaga o'qish (signed URL orqali)
DROP POLICY IF EXISTS "test_files_admin_write" ON storage.objects;
CREATE POLICY "test_files_admin_write" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'test-files'
    AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin'))
  );

DROP POLICY IF EXISTS "test_files_admin_delete" ON storage.objects;
CREATE POLICY "test_files_admin_delete" ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'test-files'
    AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin'))
  );

DROP POLICY IF EXISTS "test_files_read" ON storage.objects;
CREATE POLICY "test_files_read" ON storage.objects FOR SELECT
  TO authenticated USING (bucket_id = 'test-files');

-- books: admin/creator yozadi, hammaga o'qish
DROP POLICY IF EXISTS "books_admin_write" ON storage.objects;
CREATE POLICY "books_admin_write" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'books'
    AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin'))
  );

DROP POLICY IF EXISTS "books_admin_delete" ON storage.objects;
CREATE POLICY "books_admin_delete" ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'books'
    AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin'))
  );

DROP POLICY IF EXISTS "books_read" ON storage.objects;
CREATE POLICY "books_read" ON storage.objects FOR SELECT
  TO authenticated USING (bucket_id = 'books');
