/*
# Smart Academy — ta'lim platformasi ma'lumotlar bazasi tuzilmasi

1. Yangi jadvallar
- `subjects` (fanlar): id, title, description, color, icon, sort_order, created_at
- `topics` (mavzular): id, subject_id, title, description, sort_order, created_at
- `lessons` (darslar/doska matni): id, topic_id, title, content (doska ko'rinishidagi matn), created_at
- `questions` (test savollari): id, topic_id, question, option_a, option_b, option_c, option_d, correct_answer (a/b/c/d), explanation
- `exams` (imtihonlar): id, title, subject_id, duration_minutes, created_at
- `exam_questions` (imtihon savollari): id, exam_id, question, option_a, option_b, option_c, option_d, correct_answer, explanation
- `tournaments` (turnirlar): id, title, description, subject_id, start_date, end_date, status, created_at
- `theme_settings` (dizayn sozlamalari): id (singleton), primary_color, accent_color, board_bg, board_text, site_name
- `ai_conversations` (AI suhbatlari tarixi — ixtiyoriy): id, topic_id, question, answer, created_at

2. Aloqalar
- subjects 1->N topics -> N lessons
- topics 1->N questions
- subjects 1->N exams -> N exam_questions
- subjects 1->N tournaments

3. Xavfsizlik
- Hamma jadvallarda RLS yoqiladi.
- Bu demo/no-auth ilova — ma'lumotlar ommaviy (anon + authenticated to'liq CRUD).
- USING (true) faqat ma'lumotlar ongli ravishda ommaviy bo'lgani uchun ishlatildi.
*/

-- Subjects (fanlar)
CREATE TABLE IF NOT EXISTS subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  color text NOT NULL DEFAULT '#0f766e',
  icon text NOT NULL DEFAULT 'BookOpen',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON subjects TO anon, authenticated;
DROP POLICY IF EXISTS "read_subjects" ON subjects;
CREATE POLICY "read_subjects" ON subjects FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_subjects" ON subjects;
CREATE POLICY "insert_subjects" ON subjects FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_subjects" ON subjects;
CREATE POLICY "update_subjects" ON subjects FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_subjects" ON subjects;
CREATE POLICY "delete_subjects" ON subjects FOR DELETE TO anon, authenticated USING (true);

-- Topics (mavzular)
CREATE TABLE IF NOT EXISTS topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE topics ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON topics TO anon, authenticated;
DROP POLICY IF EXISTS "read_topics" ON topics;
CREATE POLICY "read_topics" ON topics FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_topics" ON topics;
CREATE POLICY "insert_topics" ON topics FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_topics" ON topics;
CREATE POLICY "update_topics" ON topics FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_topics" ON topics;
CREATE POLICY "delete_topics" ON topics FOR DELETE TO anon, authenticated USING (true);

-- Lessons (darslar — doska matni)
CREATE TABLE IF NOT EXISTS lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id uuid NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON lessons TO anon, authenticated;
DROP POLICY IF EXISTS "read_lessons" ON lessons;
CREATE POLICY "read_lessons" ON lessons FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_lessons" ON lessons;
CREATE POLICY "insert_lessons" ON lessons FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_lessons" ON lessons;
CREATE POLICY "update_lessons" ON lessons FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_lessons" ON lessons;
CREATE POLICY "delete_lessons" ON lessons FOR DELETE TO anon, authenticated USING (true);

-- Questions (test savollari — har mavzu ostida 10 ta)
CREATE TABLE IF NOT EXISTS questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id uuid NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  question text NOT NULL,
  option_a text NOT NULL,
  option_b text NOT NULL,
  option_c text NOT NULL,
  option_d text NOT NULL,
  correct_answer text NOT NULL CHECK (correct_answer IN ('a','b','c','d')),
  explanation text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON questions TO anon, authenticated;
DROP POLICY IF EXISTS "read_questions" ON questions;
CREATE POLICY "read_questions" ON questions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_questions" ON questions;
CREATE POLICY "insert_questions" ON questions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_questions" ON questions;
CREATE POLICY "update_questions" ON questions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_questions" ON questions;
CREATE POLICY "delete_questions" ON questions FOR DELETE TO anon, authenticated USING (true);

-- Exams (imtihonlar)
CREATE TABLE IF NOT EXISTS exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  subject_id uuid NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  duration_minutes int NOT NULL DEFAULT 30,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON exams TO anon, authenticated;
DROP POLICY IF EXISTS "read_exams" ON exams;
CREATE POLICY "read_exams" ON exams FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_exams" ON exams;
CREATE POLICY "insert_exams" ON exams FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_exams" ON exams;
CREATE POLICY "update_exams" ON exams FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_exams" ON exams;
CREATE POLICY "delete_exams" ON exams FOR DELETE TO anon, authenticated USING (true);

-- Exam questions
CREATE TABLE IF NOT EXISTS exam_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  question text NOT NULL,
  option_a text NOT NULL,
  option_b text NOT NULL,
  option_c text NOT NULL,
  option_d text NOT NULL,
  correct_answer text NOT NULL CHECK (correct_answer IN ('a','b','c','d')),
  explanation text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE exam_questions ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON exam_questions TO anon, authenticated;
DROP POLICY IF EXISTS "read_exam_questions" ON exam_questions;
CREATE POLICY "read_exam_questions" ON exam_questions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_exam_questions" ON exam_questions;
CREATE POLICY "insert_exam_questions" ON exam_questions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_exam_questions" ON exam_questions;
CREATE POLICY "update_exam_questions" ON exam_questions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_exam_questions" ON exam_questions;
CREATE POLICY "delete_exam_questions" ON exam_questions FOR DELETE TO anon, authenticated USING (true);

-- Tournaments (turnirlar)
CREATE TABLE IF NOT EXISTS tournaments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  subject_id uuid REFERENCES subjects(id) ON DELETE SET NULL,
  start_date timestamptz,
  end_date timestamptz,
  status text NOT NULL DEFAULT 'upcoming' CHECK (status IN ('upcoming','active','completed')),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE tournaments ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON tournaments TO anon, authenticated;
DROP POLICY IF EXISTS "read_tournaments" ON tournaments;
CREATE POLICY "read_tournaments" ON tournaments FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_tournaments" ON tournaments;
CREATE POLICY "insert_tournaments" ON tournaments FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_tournaments" ON tournaments;
CREATE POLICY "update_tournaments" ON tournaments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_tournaments" ON tournaments;
CREATE POLICY "delete_tournaments" ON tournaments FOR DELETE TO anon, authenticated USING (true);

-- Theme settings (singleton)
CREATE TABLE IF NOT EXISTS theme_settings (
  id int PRIMARY KEY DEFAULT 1,
  site_name text NOT NULL DEFAULT 'Smart Academy',
  primary_color text NOT NULL DEFAULT '#0f766e',
  accent_color text NOT NULL DEFAULT '#f59e0b',
  board_bg text NOT NULL DEFAULT '#1a1a1a',
  board_text text NOT NULL DEFAULT '#f5f5f5',
  CHECK (id = 1)
);
ALTER TABLE theme_settings ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON theme_settings TO anon, authenticated;
DROP POLICY IF EXISTS "read_theme" ON theme_settings;
CREATE POLICY "read_theme" ON theme_settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_theme" ON theme_settings;
CREATE POLICY "insert_theme" ON theme_settings FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_theme" ON theme_settings;
CREATE POLICY "update_theme" ON theme_settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_theme" ON theme_settings;
CREATE POLICY "delete_theme" ON theme_settings FOR DELETE TO anon, authenticated USING (true);

-- AI conversation log
CREATE TABLE IF NOT EXISTS ai_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id uuid REFERENCES topics(id) ON DELETE SET NULL,
  question text NOT NULL,
  answer text NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE ai_conversations ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON ai_conversations TO anon, authenticated;
DROP POLICY IF EXISTS "read_ai_conv" ON ai_conversations;
CREATE POLICY "read_ai_conv" ON ai_conversations FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_ai_conv" ON ai_conversations;
CREATE POLICY "insert_ai_conv" ON ai_conversations FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "delete_ai_conv" ON ai_conversations;
CREATE POLICY "delete_ai_conv" ON ai_conversations FOR DELETE TO anon, authenticated USING (true);
