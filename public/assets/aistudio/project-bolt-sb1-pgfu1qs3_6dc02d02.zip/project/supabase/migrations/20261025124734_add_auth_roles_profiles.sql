/*
# Smart Academy — Auth, Roles & User Features

1. Yangi jadvallar
- `profiles`: foydalanuvchi profillari (rol, rasm, ism). auth.users ga FK.
- `admin_codes`: admin tayinlash uchun bir martalik tasdiqlash kodlari.
- `user_themes`: har bir foydalanuvchi uchun shaxsiy dizayn sozlamalari.
- `test_files`: admin yuklagan test fayllari (PDF/Word) metadatasi.

2. Rollar
- `creator` (yaratuvchi): hamma narsani boshqaradi, admin tayinlaydi, emailini o'zgartiradi.
- `admin`: kontent boshqaruvi (fanlar, mavzular, darslar, testlar, imtihonlar, turnirlar, test fayllari).
- `student` (o'quvchi): kontentni ko'radi, dars va imtihon topshiradi, AI dan foydalanadi.

3. Xavfsizlik
- profiles: o'quvchi faqat o'zini o'qiydi/tahrirlaydi (display_name, avatar_url). role faqat SECURITY DEFINER funksiya orqali.
- admin_codes: faqat creator o'qiydi/yaratadi. Bir martalik, atomik claim.
- user_themes: har foydalanuvchi faqat o'ziniki.
- subjects/topics/lessons/questions/exams/exam_questions/tournaments: o'quvchiga SELECT, adminga CRUD.
- SECURITY DEFINER funksiyalar: generate_admin_code, confirm_admin_code, set_creator_email.
*/

-- ============ PROFILES ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'student' CHECK (role IN ('creator','admin','student')),
  display_name text,
  avatar_url text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON profiles TO authenticated;
GRANT UPDATE (display_name, avatar_url) ON profiles TO authenticated;

DROP POLICY IF EXISTS "read_own_profile" ON profiles;
CREATE POLICY "read_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============ ADMIN CODES (bir martalik) ============
CREATE TABLE IF NOT EXISTS admin_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  target_email text NOT NULL,
  created_by uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  used_at timestamptz,
  used_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  CHECK (used_at IS NULL OR used_by IS NOT NULL)
);
ALTER TABLE admin_codes ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON admin_codes TO authenticated;

DROP POLICY IF EXISTS "creator_read_codes" ON admin_codes;
CREATE POLICY "creator_read_codes" ON admin_codes FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'creator')
  );

DROP POLICY IF EXISTS "creator_insert_codes" ON admin_codes;
CREATE POLICY "creator_insert_codes" ON admin_codes FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'creator')
  );

-- ============ USER THEMES (per-user dizayn) ============
CREATE TABLE IF NOT EXISTS user_themes (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  primary_color text NOT NULL DEFAULT '#0f766e',
  accent_color text NOT NULL DEFAULT '#f59e0b',
  board_bg text NOT NULL DEFAULT '#1a1a1a',
  board_text text NOT NULL DEFAULT '#f5f5f5',
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE user_themes ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON user_themes TO authenticated;

DROP POLICY IF EXISTS "read_own_theme" ON user_themes;
CREATE POLICY "read_own_theme" ON user_themes FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "upsert_own_theme" ON user_themes;
CREATE POLICY "upsert_own_theme" ON user_themes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_theme" ON user_themes;
CREATE POLICY "update_own_theme" ON user_themes FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_theme" ON user_themes;
CREATE POLICY "delete_own_theme" ON user_themes FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ TEST FILES (admin yuklagan) ============
CREATE TABLE IF NOT EXISTS test_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id uuid REFERENCES topics(id) ON DELETE SET NULL,
  title text NOT NULL,
  file_path text NOT NULL,
  file_type text,
  file_size bigint,
  uploaded_by uuid NOT NULL REFERENCES profiles(id),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE test_files ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON test_files TO authenticated;

DROP POLICY IF EXISTS "students_read_test_files" ON test_files;
CREATE POLICY "students_read_test_files" ON test_files FOR SELECT
  TO authenticated USING (true);

GRANT INSERT, DELETE ON test_files TO authenticated;
DROP POLICY IF EXISTS "admin_insert_test_files" ON test_files;
CREATE POLICY "admin_insert_test_files" ON test_files FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin'))
  );
DROP POLICY IF EXISTS "admin_delete_test_files" ON test_files;
CREATE POLICY "admin_delete_test_files" ON test_files FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin'))
  );

-- ============ signup da profile avtomatik yaratish (creator emailini tanib olish) ============
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $f$
DECLARE
  v_creator_email text;
BEGIN
  SELECT email INTO v_creator_email FROM profiles WHERE role = 'creator' LIMIT 1;

  INSERT INTO profiles (id, email, role, display_name)
  VALUES (
    NEW.id,
    NEW.email,
    CASE
      WHEN v_creator_email IS NOT NULL AND lower(NEW.email) = lower(v_creator_email) THEN 'creator'
      WHEN lower(NEW.email) = lower('dilshodbekrayimov6@gmail.com') THEN 'creator'
      ELSE 'student'
    END,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1))
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$f$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

REVOKE EXECUTE ON FUNCTION handle_new_user() FROM PUBLIC, anon;

-- ============ Admin tayinlash: kod generatsiya + tasdiqlash ============
CREATE OR REPLACE FUNCTION generate_admin_code(p_target_email text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $f$
DECLARE
  v_code text;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'creator') THEN
    RAISE EXCEPTION 'Faqat yaratuvchi admin kodi generatsiya qila oladi';
  END IF;

  v_code := lpad(floor(random() * 1000000)::text, 6, '0');

  INSERT INTO admin_codes (code, target_email, created_by)
  VALUES (v_code, p_target_email, auth.uid());

  RETURN v_code;
END;
$f$;

REVOKE EXECUTE ON FUNCTION generate_admin_code(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION generate_admin_code(text) TO authenticated;

CREATE OR REPLACE FUNCTION confirm_admin_code(p_code text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $f$
DECLARE
  v_target text;
  v_my_email text;
BEGIN
  SELECT email INTO v_my_email FROM profiles WHERE id = auth.uid();
  IF v_my_email IS NULL THEN
    RAISE EXCEPTION 'Profil topilmadi';
  END IF;

  UPDATE admin_codes
  SET used_at = now(), used_by = auth.uid()
  WHERE code = p_code
    AND used_at IS NULL
    AND target_email = v_my_email
  RETURNING target_email INTO v_target;

  IF v_target IS NULL THEN
    RAISE EXCEPTION 'Kod yaroqsiz yoki allaqachon ishlatilgan';
  END IF;

  UPDATE profiles SET role = 'admin' WHERE id = auth.uid();
  RETURN true;
END;
$f$;

REVOKE EXECUTE ON FUNCTION confirm_admin_code(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION confirm_admin_code(text) TO authenticated;

-- ============ Creator emailini o'zgartirish ============
CREATE OR REPLACE FUNCTION set_creator_email(p_new_email text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $f$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'creator') THEN
    RAISE EXCEPTION 'Faqat yaratuvchi o''zgartira oladi';
  END IF;
  IF p_new_email !~ '^[^@]+@[^@]+\.[^@]+$' THEN
    RAISE EXCEPTION 'Email formati noto''g''ri';
  END IF;
  UPDATE profiles SET email = p_new_email WHERE id = auth.uid() AND role = 'creator';
END;
$f$;

REVOKE EXECUTE ON FUNCTION set_creator_email(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION set_creator_email(text) TO authenticated;

-- ============ ADMIN-ga kontent CRUD, STUDENT-ga faqat SELECT ============
REVOKE INSERT, UPDATE, DELETE ON subjects FROM anon, authenticated;
GRANT SELECT ON subjects TO authenticated;
GRANT INSERT, UPDATE, DELETE ON subjects TO authenticated;

DROP POLICY IF EXISTS "students_read_subjects" ON subjects;
CREATE POLICY "students_read_subjects" ON subjects FOR SELECT
  TO authenticated USING (true);
DROP POLICY IF EXISTS "admin_write_subjects" ON subjects;
CREATE POLICY "admin_write_subjects" ON subjects FOR ALL
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')));

REVOKE INSERT, UPDATE, DELETE ON topics FROM anon, authenticated;
GRANT SELECT ON topics TO authenticated;
GRANT INSERT, UPDATE, DELETE ON topics TO authenticated;

DROP POLICY IF EXISTS "read_topics" ON topics;
CREATE POLICY "read_topics" ON topics FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admin_write_topics" ON topics;
CREATE POLICY "admin_write_topics" ON topics FOR ALL
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')));

REVOKE INSERT, UPDATE, DELETE ON lessons FROM anon, authenticated;
GRANT SELECT ON lessons TO authenticated;
GRANT INSERT, UPDATE, DELETE ON lessons TO authenticated;

DROP POLICY IF EXISTS "read_lessons" ON lessons;
CREATE POLICY "read_lessons" ON lessons FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admin_write_lessons" ON lessons;
CREATE POLICY "admin_write_lessons" ON lessons FOR ALL
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')));

REVOKE INSERT, UPDATE, DELETE ON questions FROM anon, authenticated;
GRANT SELECT ON questions TO authenticated;
GRANT INSERT, UPDATE, DELETE ON questions TO authenticated;

DROP POLICY IF EXISTS "read_questions" ON questions;
CREATE POLICY "read_questions" ON questions FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admin_write_questions" ON questions;
CREATE POLICY "admin_write_questions" ON questions FOR ALL
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')));

REVOKE INSERT, UPDATE, DELETE ON exams FROM anon, authenticated;
GRANT SELECT ON exams TO authenticated;
GRANT INSERT, UPDATE, DELETE ON exams TO authenticated;

DROP POLICY IF EXISTS "read_exams" ON exams;
CREATE POLICY "read_exams" ON exams FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admin_write_exams" ON exams;
CREATE POLICY "admin_write_exams" ON exams FOR ALL
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')));

REVOKE INSERT, UPDATE, DELETE ON exam_questions FROM anon, authenticated;
GRANT SELECT ON exam_questions TO authenticated;
GRANT INSERT, UPDATE, DELETE ON exam_questions TO authenticated;

DROP POLICY IF EXISTS "read_exam_questions" ON exam_questions;
CREATE POLICY "read_exam_questions" ON exam_questions FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admin_write_exam_questions" ON exam_questions;
CREATE POLICY "admin_write_exam_questions" ON exam_questions FOR ALL
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')));

REVOKE INSERT, UPDATE, DELETE ON tournaments FROM anon, authenticated;
GRANT SELECT ON tournaments TO authenticated;
GRANT INSERT, UPDATE, DELETE ON tournaments TO authenticated;

DROP POLICY IF EXISTS "read_tournaments" ON tournaments;
CREATE POLICY "read_tournaments" ON tournaments FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admin_write_tournaments" ON tournaments;
CREATE POLICY "admin_write_tournaments" ON tournaments FOR ALL
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')));

REVOKE INSERT, UPDATE, DELETE ON theme_settings FROM anon, authenticated;
GRANT SELECT ON theme_settings TO authenticated;
GRANT INSERT, UPDATE, DELETE ON theme_settings TO authenticated;

DROP POLICY IF EXISTS "read_theme" ON theme_settings;
CREATE POLICY "read_theme" ON theme_settings FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admin_write_theme" ON theme_settings;
CREATE POLICY "admin_write_theme" ON theme_settings FOR ALL
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('creator','admin')));

-- ai_conversations: har foydalanuvchi o'zinikini yozadi
ALTER TABLE ai_conversations ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES profiles(id) ON DELETE SET NULL;
ALTER TABLE ai_conversations ALTER COLUMN user_id SET DEFAULT auth.uid();

REVOKE DELETE ON ai_conversations FROM anon, authenticated;
GRANT SELECT, INSERT ON ai_conversations TO authenticated;

DROP POLICY IF EXISTS "insert_ai_conv" ON ai_conversations;
CREATE POLICY "insert_ai_conv" ON ai_conversations FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid() OR user_id IS NULL);
DROP POLICY IF EXISTS "read_ai_conv" ON ai_conversations;
CREATE POLICY "read_ai_conv" ON ai_conversations FOR SELECT
  TO authenticated USING (user_id = auth.uid() OR user_id IS NULL);
