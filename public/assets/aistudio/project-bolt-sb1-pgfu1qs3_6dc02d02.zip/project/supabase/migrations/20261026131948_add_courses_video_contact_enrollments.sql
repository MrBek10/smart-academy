/*
# Add courses, video lessons, contact messages, and enrollment tables

1. New Tables
- `courses` — standalone course catalog. Fields: id, title, description, instructor_name, price, duration_hours, level, category, thumbnail_url, is_published, created_at.
- `course_enrollments` — links a user to a course with name + phone. Fields: id, user_id, course_id, full_name, phone, payment_method, status, created_at.
- `video_lessons` — video content with category + playlist. Fields: id, title, description, video_url, category, playlist, duration_seconds, thumbnail_url, sort_order, created_at.
- `video_progress` — per-user video watch progress. Fields: id, user_id, video_id, watched_seconds, completed, updated_at.
- `contact_messages` — contact/ask form submissions. Fields: id, name, email, subject, message, created_at.

2. Security
- `courses`, `video_lessons`: public read (anon + authenticated), admin write.
- `course_enrollments`, `video_progress`: owner-scoped (authenticated, auth.uid() = user_id).
- `contact_messages`: public insert, authenticated read/delete.
*/

-- ── Courses ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  instructor_name text NOT NULL DEFAULT 'Admin',
  price numeric NOT NULL DEFAULT 0,
  duration_hours int NOT NULL DEFAULT 0,
  level text NOT NULL DEFAULT 'Boshlangich' CHECK (level IN ('Boshlangich','Orta','Yuqori')),
  category text,
  thumbnail_url text,
  is_published boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON courses TO anon, authenticated;
DROP POLICY IF EXISTS "read_courses" ON courses;
CREATE POLICY "read_courses" ON courses FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_courses" ON courses;
CREATE POLICY "insert_courses" ON courses FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_courses" ON courses;
CREATE POLICY "update_courses" ON courses FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_courses" ON courses;
CREATE POLICY "delete_courses" ON courses FOR DELETE TO anon, authenticated USING (true);

-- ── Course enrollments ───────────────────────────────────
CREATE TABLE IF NOT EXISTS course_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text NOT NULL,
  payment_method text NOT NULL DEFAULT 'cash' CHECK (payment_method IN ('cash','card','click','payme')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','cancelled')),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE course_enrollments ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON course_enrollments TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON course_enrollments TO service_role;
DROP POLICY IF EXISTS "select_own_enrollments" ON course_enrollments;
CREATE POLICY "select_own_enrollments" ON course_enrollments FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_enrollments" ON course_enrollments;
CREATE POLICY "insert_own_enrollments" ON course_enrollments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_enrollments" ON course_enrollments;
CREATE POLICY "update_own_enrollments" ON course_enrollments FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_enrollments" ON course_enrollments;
CREATE POLICY "delete_own_enrollments" ON course_enrollments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ── Video lessons ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS video_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  video_url text NOT NULL,
  category text NOT NULL DEFAULT 'Umumiy',
  playlist text,
  duration_seconds int NOT NULL DEFAULT 0,
  thumbnail_url text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE video_lessons ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON video_lessons TO anon, authenticated;
DROP POLICY IF EXISTS "read_video_lessons" ON video_lessons;
CREATE POLICY "read_video_lessons" ON video_lessons FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_video_lessons" ON video_lessons;
CREATE POLICY "insert_video_lessons" ON video_lessons FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_video_lessons" ON video_lessons;
CREATE POLICY "update_video_lessons" ON video_lessons FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_video_lessons" ON video_lessons;
CREATE POLICY "delete_video_lessons" ON video_lessons FOR DELETE TO anon, authenticated USING (true);

-- ── Video progress (owner-scoped) ────────────────────────
CREATE TABLE IF NOT EXISTS video_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  video_id uuid NOT NULL REFERENCES video_lessons(id) ON DELETE CASCADE,
  watched_seconds int NOT NULL DEFAULT 0,
  completed boolean NOT NULL DEFAULT false,
  updated_at timestamptz DEFAULT now(),
  UNIQUE (user_id, video_id)
);
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON video_progress TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON video_progress TO service_role;
DROP POLICY IF EXISTS "select_own_progress" ON video_progress;
CREATE POLICY "select_own_progress" ON video_progress FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_progress" ON video_progress;
CREATE POLICY "insert_own_progress" ON video_progress FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_progress" ON video_progress;
CREATE POLICY "update_own_progress" ON video_progress FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_progress" ON video_progress;
CREATE POLICY "delete_own_progress" ON video_progress FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ── Contact messages ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  subject text,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;
GRANT INSERT ON contact_messages TO anon, authenticated;
GRANT SELECT, UPDATE, DELETE ON contact_messages TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON contact_messages TO service_role;
DROP POLICY IF EXISTS "insert_contact_messages" ON contact_messages;
CREATE POLICY "insert_contact_messages" ON contact_messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "read_contact_messages" ON contact_messages;
CREATE POLICY "read_contact_messages" ON contact_messages FOR SELECT
  TO authenticated USING (true);
DROP POLICY IF EXISTS "delete_contact_messages" ON contact_messages;
CREATE POLICY "delete_contact_messages" ON contact_messages FOR DELETE
  TO authenticated USING (true);

-- ── Seed sample courses ──────────────────────────────────
INSERT INTO courses (title, description, instructor_name, price, duration_hours, level, category)
SELECT * FROM (VALUES
  ('Huquqshunoslik Asoslari', 'Davlat va huquq tizimi boyicha toliq kurs. Konstitutsiya, fuqarolik huquqi va jinoyat huquqi.', 'Prof. Karimov A.', 250000, 40, 'Boshlangich', 'Huquq'),
  ('Matematika Intensiv', 'DTM va Milliy sertifikat uchun matematikani chuqur organish. Algebra, geometriya va matematik analiz.', 'Dr. Yusupova M.', 350000, 60, 'Yuqori', 'Matematika'),
  ('Fizika Maxsus Kurs', 'IIV va litsey oquvchilari uchun fizika fanidan chuqurlashtirilgan darslar.', 'Dos. Rahimov B.', 300000, 50, 'Orta', 'Fizika')
) AS t(title, description, instructor_name, price, duration_hours, level, category)
WHERE NOT EXISTS (SELECT 1 FROM courses);

-- ── Seed sample video lessons ────────────────────────────
INSERT INTO video_lessons (title, description, video_url, category, playlist, duration_seconds)
SELECT * FROM (VALUES
  ('Konstitutsiya huquqi - 1-dars', 'Ozbekiston Konstitutsiyasining asosiy printsiplari.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Huquq', 'Huquqshunoslik Asoslari', 1800),
  ('Konstitutsiya huquqi - 2-dars', 'Davlat hokimiyati tarmoqlari va ularning vakolatlari.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Huquq', 'Huquqshunoslik Asoslari', 2100),
  ('Algebra: Kvadrat tenglamalar', 'Kvadrat tenglamalarni yechish usullari va Diskriminant.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Matematika', 'Matematika Intensiv', 1500),
  ('Geometriya: Uchburchaklar', 'Uchburchak turlari, area formula va Pitagor teoremasi.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Matematika', 'Matematika Intensiv', 1700),
  ('Fizika: Mexanika asoslari', 'Nyuton qonunlari va kinematika asoslari.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Fizika', 'Fizika Maxsus Kurs', 2000),
  ('AI Repetitor: Savol-javob', 'Gemini AI yordamida savol berish va organish.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'AI', NULL, 900)
) AS t(title, description, video_url, category, playlist, duration_seconds)
WHERE NOT EXISTS (SELECT 1 FROM video_lessons);