/*
# Add exam_type column to exams

1. Modified Tables
- `exams`: add `exam_type` text column (values: 'dtm', 'milliy_sertifikat', 'mavzuviy'), default 'mavzuviy'.
2. Notes
- Categorizes exams into three panels in the Exam Room UI.
- Existing rows default to 'mavzuviy'.
*/

ALTER TABLE public.exams
  ADD COLUMN IF NOT EXISTS exam_type text NOT NULL DEFAULT 'mavzuviy' CHECK (exam_type IN ('dtm', 'milliy_sertifikat', 'mavzuviy'));
