/*
# Add audio library and personal soundtrack storage

1. New Tables
- `audio_files`: authenticated users' private MP3 uploads for the focus music player.
- `book_categories`: user-created library categories, visible to signed-in users and owned for changes.

2. Modified Tables
- `books.category_id`: optional category assigned to a book.
- `books.is_audio`: marks a book as an audio book.
- `books.audio_path`: private storage path for an audio-book file.

3. Storage
- Adds private `audio-files` bucket for user soundtracks and administrator audio-book uploads.
- User uploads are restricted to their own folder.

4. Security
- Enables RLS on both new tables.
- Grants only the verbs needed by authenticated users.
- User audio records are owner-scoped.
- Categories can be read by authenticated users, but changed only by their creator or an administrator.
- Existing book access rules remain in place.

5. Important Notes
- Existing books and files are preserved.
- Audio fields are nullable so current records continue working.
- The client must use signed URLs for private audio playback.
*/

CREATE TABLE IF NOT EXISTS public.book_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS book_categories_name_creator_key
  ON public.book_categories (lower(name), created_by);

CREATE TABLE IF NOT EXISTS public.audio_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  file_path text NOT NULL,
  file_type text NOT NULL DEFAULT 'audio/mpeg',
  file_size bigint,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.books
  ADD COLUMN IF NOT EXISTS category_id uuid REFERENCES public.book_categories(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS is_audio boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS audio_path text;

ALTER TABLE public.book_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audio_files ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, DELETE ON public.audio_files TO authenticated;
GRANT SELECT, INSERT, DELETE ON public.book_categories TO authenticated;
GRANT UPDATE (category_id, is_audio, audio_path) ON public.books TO authenticated;

DROP POLICY IF EXISTS "authenticated_read_book_categories" ON public.book_categories;
CREATE POLICY "authenticated_read_book_categories" ON public.book_categories
  FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "users_create_book_categories" ON public.book_categories;
CREATE POLICY "users_create_book_categories" ON public.book_categories
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
DROP POLICY IF EXISTS "owners_delete_book_categories" ON public.book_categories;
CREATE POLICY "owners_delete_book_categories" ON public.book_categories
  FOR DELETE TO authenticated USING (created_by = auth.uid() OR EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('creator', 'admin')
  ));

DROP POLICY IF EXISTS "users_read_own_audio_files" ON public.audio_files;
CREATE POLICY "users_read_own_audio_files" ON public.audio_files
  FOR SELECT TO authenticated USING (user_id = auth.uid());
DROP POLICY IF EXISTS "users_create_own_audio_files" ON public.audio_files;
CREATE POLICY "users_create_own_audio_files" ON public.audio_files
  FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS "users_delete_own_audio_files" ON public.audio_files;
CREATE POLICY "users_delete_own_audio_files" ON public.audio_files
  FOR DELETE TO authenticated USING (user_id = auth.uid());

INSERT INTO storage.buckets (id, name, public)
VALUES ('audio-files', 'audio-files', false)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "audio_files_read_own_folder" ON storage.objects;
CREATE POLICY "audio_files_read_own_folder" ON storage.objects
  FOR SELECT TO authenticated USING (
    bucket_id = 'audio-files' AND (storage.foldername(name))[1] = auth.uid()::text
  );
DROP POLICY IF EXISTS "audio_files_insert_own_folder" ON storage.objects;
CREATE POLICY "audio_files_insert_own_folder" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (
    bucket_id = 'audio-files' AND (storage.foldername(name))[1] = auth.uid()::text
  );
DROP POLICY IF EXISTS "audio_files_delete_own_folder" ON storage.objects;
CREATE POLICY "audio_files_delete_own_folder" ON storage.objects
  FOR DELETE TO authenticated USING (
    bucket_id = 'audio-files' AND (storage.foldername(name))[1] = auth.uid()::text
  );
