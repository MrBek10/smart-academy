import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("GEMINI_API_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: "Gemini API kaliti sozlanmagan. Iltimos, GEMINI_API_KEY sirtni qo'shing." }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const authHeader = req.headers.get("Authorization");
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Optional auth: verify user token if provided
    let userId: string | null = null;
    if (authHeader) {
      const token = authHeader.replace("Bearer ", "");
      const { data: userData } = await supabase.auth.getUser(token);
      userId = userData.user?.id ?? null;
    }

    const body = await req.json();
    const { question, lessonContent, topicTitle } = body as {
      question: string;
      lessonContent?: string;
      topicTitle?: string;
    };

    if (!question || typeof question !== "string" || question.length > 2000) {
      return new Response(
        JSON.stringify({ error: "Savol noto'g'ri yoki juda uzun." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const systemPrompt = `Siz Smart Academy platformasining AI repetitorisiz. O'zbek tilida, sodda va tushunarli tarzda o'quvchilarga dars materiallari bo'yicha javob bering. ${topicTitle ? `Mavzu: ${topicTitle}.` : ""} ${lessonContent ? `Dars matni: ${lessonContent.slice(0, 3000)}` : "Dars matni mavjud emas, umumiy bilimlaringizdan foydalaning."} Javobni 200 so'zdan qisqa va aniq yozing.`;

    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;

    const geminiRes = await fetch(geminiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [{ text: `${systemPrompt}\n\nO'quvchi savoli: ${question}` }],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 400,
        },
      }),
    });

    if (!geminiRes.ok) {
      const errText = await geminiRes.text();
      console.error("Gemini API xatosi:", geminiRes.status, errText);
      return new Response(
        JSON.stringify({ error: "AI javob bera olmadi. Iltimos keyinroq urinib ko'ring." }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const geminiData = await geminiRes.json();
    const answer =
      geminiData?.candidates?.[0]?.content?.parts?.[0]?.text ??
      "AI javob topa olmadi. Iltimos savolni aniqlashtiring.";

    // Log conversation best-effort
    if (userId) {
      await supabase.from("ai_conversations").insert({
        question,
        answer,
        user_id: userId,
      }).then(() => {}, () => {});
    }

    return new Response(
      JSON.stringify({ answer }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Edge function xatosi:", err);
    return new Response(
      JSON.stringify({ error: "Server xatosi." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
