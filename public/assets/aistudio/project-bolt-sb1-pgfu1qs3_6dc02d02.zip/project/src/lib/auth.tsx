import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase, Profile, UserTheme, Role } from './supabase';

type AuthContextValue = {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  role: Role | 'guest';
  userTheme: UserTheme | null;
  loading: boolean;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  refreshUserTheme: () => Promise<void>;
  enterGuest: () => void;
  isGuest: boolean;
};

const AuthContext = createContext<AuthContextValue>({
  session: null,
  user: null,
  profile: null,
  role: 'guest',
  userTheme: null,
  loading: true,
  signOut: async () => {},
  refreshProfile: async () => {},
  refreshUserTheme: async () => {},
  enterGuest: () => {},
  isGuest: false,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [userTheme, setUserTheme] = useState<UserTheme | null>(null);
  const [loading, setLoading] = useState(true);
  const [isGuest, setIsGuest] = useState(false);

  const loadProfile = async (u: User) => {
    const { data } = await supabase.from('profiles').select('*').eq('id', u.id).maybeSingle();
    setProfile(data as Profile | null);
  };

  const loadUserTheme = async (u: User) => {
    const { data } = await supabase.from('user_themes').select('*').eq('user_id', u.id).maybeSingle();
    setUserTheme(data as UserTheme | null);
  };

  useEffect(() => {
    supabase.auth.onAuthStateChange((_event, sess) => {
      (async () => {
        setSession(sess);
        setUser(sess?.user ?? null);
        if (sess?.user) {
          await Promise.all([loadProfile(sess.user), loadUserTheme(sess.user)]);
          setIsGuest(false);
        } else {
          setProfile(null);
          setUserTheme(null);
        }
        setLoading(false);
      })();
    });
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setUserTheme(null);
    setIsGuest(false);
  };

  const enterGuest = () => {
    setIsGuest(true);
    setLoading(false);
  };

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        profile,
        role: profile?.role ?? (isGuest ? 'guest' : 'guest'),
        userTheme,
        loading,
        signOut,
        refreshProfile: async () => { if (user) await loadProfile(user); },
        refreshUserTheme: async () => { if (user) await loadUserTheme(user); },
        enterGuest,
        isGuest,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
