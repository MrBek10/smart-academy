import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase, ThemeSettings, UserTheme } from './supabase';
import { useAuth } from './auth';

type ThemeContextValue = {
  globalTheme: ThemeSettings | null;
  userTheme: UserTheme | null;
  loading: boolean;
  refresh: () => Promise<void>;
};

const ThemeContext = createContext<ThemeContextValue>({
  globalTheme: null,
  userTheme: null,
  loading: true,
  refresh: async () => {},
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  const { user, profile } = useAuth();
  const [globalTheme, setGlobalTheme] = useState<ThemeSettings | null>(null);
  const [userTheme, setUserTheme] = useState<UserTheme | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const { data } = await supabase.from('theme_settings').select('*').eq('id', 1).maybeSingle();
    setGlobalTheme(data as ThemeSettings | null);
    setLoading(false);
  };

  const loadUser = async (u: typeof user) => {
    if (!u) { setUserTheme(null); return; }
    const { data } = await supabase.from('user_themes').select('*').eq('user_id', u.id).maybeSingle();
    setUserTheme(data as UserTheme | null);
  };

  useEffect(() => { load(); }, []);
  useEffect(() => { loadUser(user); }, [user, profile?.id]);

  // User theme ustuvor, aks holda global default
  const effective = userTheme ?? globalTheme;
  useEffect(() => {
    if (!effective) return;
    const root = document.documentElement;
    root.style.setProperty('--theme-primary', (userTheme ?? globalTheme)?.primary_color ?? '#0f766e');
    root.style.setProperty('--theme-accent', (userTheme ?? globalTheme)?.accent_color ?? '#f59e0b');
    root.style.setProperty('--board-bg', (userTheme ?? globalTheme)?.board_bg ?? '#1a1a1a');
    root.style.setProperty('--board-text', (userTheme ?? globalTheme)?.board_text ?? '#f5f5f5');
    if (globalTheme) document.title = globalTheme.site_name;
  }, [effective, userTheme, globalTheme]);

  return (
    <ThemeContext.Provider value={{ globalTheme, userTheme, loading, refresh: load }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
