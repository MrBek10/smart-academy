import { useState } from 'react';
import { GraduationCap, Menu, X, User as UserIcon, LogOut, LayoutDashboard, BookOpen, Trophy, Library, Eye, EyeOff, Headphones, Video, Sparkles, Mail, GraduationCap as CourseIcon } from 'lucide-react';
import { AuthProvider, useAuth } from '@/lib/auth';
import { ThemeProvider, useTheme } from '@/lib/theme';
import { ToastProvider } from '@/components/Toast';
import Landing from '@/views/Landing';
import StudentHome from '@/views/StudentHome';
import SubjectDetail from '@/views/SubjectDetail';
import Classroom from '@/views/Classroom';
import ExamRoom from '@/views/ExamRoom';
import ExamList from '@/views/ExamList';
import AdminPanel from '@/views/AdminPanel';
import Tournaments from '@/views/Tournaments';
import ProfilePage from '@/views/ProfilePage';
import LibraryPage from '@/views/Library';
import MusicPlayer from '@/views/MusicPlayer';
import VideoLessons from '@/views/VideoLessons';
import Courses from '@/views/Courses';
import CourseDetail from '@/views/CourseDetail';
import AIAssistant from '@/views/AIAssistant';
import ContactForm from '@/components/ContactForm';

type Route =
  | { name: 'home' }
  | { name: 'subject'; subjectId: string }
  | { name: 'classroom'; topicId: string }
  | { name: 'exams' }
  | { name: 'exam'; examId: string }
  | { name: 'admin' }
  | { name: 'tournaments' }
  | { name: 'library' }
  | { name: 'profile' }
  | { name: 'video' }
  | { name: 'courses' }
  | { name: 'course'; courseId: string }
  | { name: 'ai' }
  | { name: 'contact' };

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <ToastProvider>
          <AppInner />
        </ToastProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}

function AppInner() {
  const { user, profile, loading, isGuest, signOut } = useAuth();
  const { globalTheme } = useTheme();
  const [route, setRoute] = useState<Route>({ name: 'home' });
  const [navOpen, setNavOpen] = useState(false);
  const [viewAsStudent, setViewAsStudent] = useState(false);
  const [showMusic, setShowMusic] = useState(false);

  const go = (r: Route) => {
    setRoute(r);
    setNavOpen(false);
    window.scrollTo(0, 0);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="text-slate-400">Yuklanmoqda...</div>
      </div>
    );
  }

  if (!user && !isGuest) {
    return <Landing onEnter={() => go({ name: 'home' })} />;
  }

  const role = profile?.role ?? 'guest';
  const isAdmin = (role === 'admin' || role === 'creator') && !viewAsStudent;
  const isActualAdmin = role === 'admin' || role === 'creator';
  const siteName = globalTheme?.site_name ?? 'Smart Academy';

  const navItems: { label: string; icon: typeof BookOpen; active: boolean; onClick: () => void }[] = [
    { label: 'Bosh sahifa', icon: BookOpen, active: route.name === 'home', onClick: () => go({ name: 'home' }) },
    { label: 'Kurslar', icon: CourseIcon, active: route.name === 'courses' || route.name === 'course', onClick: () => go({ name: 'courses' }) },
    { label: 'Video Darslar', icon: Video, active: route.name === 'video', onClick: () => go({ name: 'video' }) },
    { label: 'Kutubxona', icon: Library, active: route.name === 'library', onClick: () => go({ name: 'library' }) },
    { label: 'Imtihon Xonasi', icon: GraduationCap, active: route.name === 'exams' || route.name === 'exam', onClick: () => go({ name: 'exams' }) },
    { label: 'AI Yordamchi', icon: Sparkles, active: route.name === 'ai', onClick: () => go({ name: 'ai' }) },
    { label: 'Bog\'lanish', icon: Mail, active: route.name === 'contact', onClick: () => go({ name: 'contact' }) },
  ];
  if (isAdmin) navItems.push({ label: 'Turnirlar', icon: Trophy, active: route.name === 'tournaments', onClick: () => go({ name: 'tournaments' }) });
  if (isAdmin) navItems.push({ label: 'Admin panel', icon: LayoutDashboard, active: route.name === 'admin', onClick: () => go({ name: 'admin' }) });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <header className="glass-strong sticky top-0 z-40 border-b border-slate-700/50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <button onClick={() => go({ name: 'home' })} className="flex items-center gap-2.5 group">
            <span className="w-9 h-9 rounded-xl flex items-center justify-center text-white shadow-sm transition-transform group-hover:scale-105 bg-gradient-to-tr from-blue-600 to-indigo-500">
              <GraduationCap className="w-5 h-5" />
            </span>
            <span className="font-bold text-lg tracking-tight text-white">{siteName}</span>
          </button>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((n) => (
              <button
                key={n.label}
                onClick={n.onClick}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${n.active ? 'text-white' : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'}`}
                style={n.active ? { background: 'linear-gradient(to right, #2563eb, #6366f1)' } : undefined}
              >
                <n.icon className="w-4 h-4" /> <span className="hidden lg:inline">{n.label}</span>
              </button>
            ))}
            <div className="w-px h-6 bg-slate-700 mx-2" />
            <button onClick={() => setShowMusic(true)} className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800/60 transition" title="Musiqa pleyeri">
              <Headphones className="w-5 h-5" />
            </button>
            {isAdmin && (
              <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${role === 'creator' ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' : 'bg-amber-500/20 text-amber-300 border-amber-500/30'}`}>
                {role === 'creator' ? 'Yaratuvchi' : 'Admin'}
              </span>
            )}
            {isActualAdmin && (
              <button onClick={() => setViewAsStudent((v) => !v)} className="px-2.5 py-1 rounded-lg text-xs font-medium border border-amber-500/30 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 transition flex items-center gap-1">
                {viewAsStudent ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                {viewAsStudent ? 'Admin rejimi' : 'Oddiy rejim'}
              </button>
            )}
            {user ? (
              <>
                <button onClick={() => go({ name: 'profile' })} className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-slate-800/60">
                  {profile?.avatar_url ? (
                    <img src={profile.avatar_url} alt="" className="w-7 h-7 rounded-full object-cover" />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center">
                      <UserIcon className="w-4 h-4 text-slate-300" />
                    </div>
                  )}
                  <span className="text-sm font-medium max-w-[120px] truncate text-slate-200">{profile?.display_name ?? profile?.email}</span>
                </button>
                <button onClick={signOut} className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors" title="Chiqish">
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : (
              <span className="px-3 py-1.5 text-xs font-semibold text-slate-400 bg-slate-800/60 rounded-lg">Mehmon</span>
            )}
          </nav>

          <button onClick={() => setNavOpen(!navOpen)} className="md:hidden p-2 rounded-lg hover:bg-slate-800/60 text-slate-200">
            {navOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {navOpen && (
          <div className="md:hidden glass border-t border-slate-700/50 px-4 py-3 space-y-1">
            {navItems.map((n) => (
              <button key={n.label} onClick={n.onClick} className={`block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium flex items-center gap-2 ${n.active ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800/60'}`}>
                <n.icon className="w-4 h-4" /> {n.label}
              </button>
            ))}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-700/50">
              <button onClick={() => setShowMusic(true)} className="px-3 py-2 rounded-lg text-sm font-medium text-slate-300 hover:bg-slate-800/60 flex items-center gap-2">
                <Headphones className="w-4 h-4" /> Musiqa
              </button>
              {user && (
                <button onClick={() => go({ name: 'profile' })} className="px-3 py-2 rounded-lg text-sm font-medium text-slate-300 hover:bg-slate-800/60 flex items-center gap-2">
                  <UserIcon className="w-4 h-4" /> Sozlamalar
                </button>
              )}
              {user && (
                <button onClick={signOut} className="px-3 py-2 rounded-lg text-sm font-medium text-red-400 hover:bg-red-500/10 flex items-center gap-2 ml-auto">
                  <LogOut className="w-4 h-4" /> Chiqish
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      <main className="flex-1">
        {route.name === 'home' && <StudentHome onOpenSubject={(id) => go({ name: 'subject', subjectId: id })} onOpenTournaments={() => go({ name: 'tournaments' })} onOpenExams={() => go({ name: 'exams' })} onOpenLibrary={() => go({ name: 'library' })} onOpenAdmin={() => go({ name: 'admin' })} onOpenCourses={() => go({ name: 'courses' })} onOpenVideo={() => go({ name: 'video' })} onOpenAI={() => go({ name: 'ai' })} onOpenContact={() => go({ name: 'contact' })} isAdmin={isAdmin} />}
        {route.name === 'subject' && (
          <SubjectDetail subjectId={route.subjectId} onOpenClassroom={(topicId) => go({ name: 'classroom', topicId })} onBack={() => go({ name: 'home' })} onOpenExam={(examId) => go({ name: 'exam', examId })} />
        )}
        {route.name === 'classroom' && <Classroom topicId={route.topicId} onBack={() => go({ name: 'home' })} onOpenSubject={(id) => go({ name: 'subject', subjectId: id })} />}
        {route.name === 'exams' && <ExamList onOpenExam={(id) => go({ name: 'exam', examId: id })} onBack={() => go({ name: 'home' })} onOpenAdmin={() => go({ name: 'admin' })} isAdmin={isAdmin} />}
        {route.name === 'exam' && <ExamRoom examId={route.examId} onBack={() => go({ name: 'exams' })} />}
        {route.name === 'library' && <LibraryPage onBack={() => go({ name: 'home' })} />}
        {route.name === 'video' && <VideoLessons onBack={() => go({ name: 'home' })} />}
        {route.name === 'courses' && <Courses onBack={() => go({ name: 'home' })} onOpenCourse={(id) => go({ name: 'course', courseId: id })} />}
        {route.name === 'course' && <CourseDetail courseId={route.courseId} onBack={() => go({ name: 'courses' })} />}
        {route.name === 'ai' && <AIAssistant onBack={() => go({ name: 'home' })} />}
        {route.name === 'contact' && (
          <div className="max-w-2xl mx-auto px-4 py-8">
            <ContactForm />
          </div>
        )}
        {route.name === 'admin' && isAdmin && <AdminPanel />}
        {route.name === 'tournaments' && isAdmin && <Tournaments canCreate={isAdmin} />}
        {route.name === 'profile' && user && <ProfilePage onBack={() => go({ name: 'home' })} />}
      </main>

      <footer className="glass border-t border-slate-800 mt-16 py-6 text-center text-xs text-slate-500">
        <p>{siteName} — Litseylar uchun AI ta'lim platformasi</p>
      </footer>

      {showMusic && <MusicPlayer onClose={() => setShowMusic(false)} />}
    </div>
  );
}
