import { useEffect, useState, useRef } from 'react';
import { ArrowLeft, BookOpen, Search, Download, BookText, Scale, Calculator, Dumbbell, Fingerprint, Headphones, Play, Pause, X, FolderPlus, Trash2 } from 'lucide-react';
import { supabase, Book, Subject, BookCategory } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { logActivity } from '@/lib/supabase';

const CATEGORY_ICONS: Record<string, typeof BookOpen> = {
  Huquq: Scale,
  Maxsus: Fingerprint,
  "Umumta'lim": Calculator,
  Sport: Dumbbell,
};

export default function Library({ onBack }: { onBack: () => void }) {
  const { user } = useAuth();
  const [books, setBooks] = useState<(Book & { subject_title: string })[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [categories, setCategories] = useState<BookCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState<string>('');
  const [newCat, setNewCat] = useState('');
  const [playingBook, setPlayingBook] = useState<Book | null>(null);

  useEffect(() => {
    (async () => {
      const [{ data: bs }, { data: subs }, { data: cats }] = await Promise.all([
        supabase.from('books').select('*').order('created_at', { ascending: false }),
        supabase.from('subjects').select('*').order('title'),
        supabase.from('book_categories').select('*').order('name'),
      ]);
      const subMap = new Map<string, Subject>((subs as Subject[])?.map((s) => [s.id, s]) ?? []);
      const enriched = ((bs as Book[]) ?? []).map((b) => ({
        ...b,
        subject_title: b.subject_id ? (subMap.get(b.subject_id)?.title ?? 'Umumiy') : 'Umumiy',
      }));
      setBooks(enriched);
      setSubjects((subs as Subject[]) ?? []);
      setCategories((cats as BookCategory[]) ?? []);
      setLoading(false);
    })();
  }, []);

  const primary = 'var(--theme-primary, #0f766e)';
  const accent = 'var(--theme-accent, #f59e0b)';

  const addCategory = async () => {
    if (!user || !newCat.trim()) return;
    const { error } = await supabase.from('book_categories').insert({ name: newCat.trim(), created_by: user.id });
    if (error) { alert('Kategoriya qo\'shilmadi: ' + error.message); return; }
    setNewCat('');
    const { data: cats } = await supabase.from('book_categories').select('*').order('name');
    setCategories((cats as BookCategory[]) ?? []);
  };

  const filtered = books.filter((b) => {
    const q = search.toLowerCase().trim();
    const matchSearch = !q || b.title.toLowerCase().includes(q) || (b.author ?? '').toLowerCase().includes(q) || (b.description ?? '').toLowerCase().includes(q) || b.subject_title.toLowerCase().includes(q);
    const matchCat = !filterCat || b.category_id === filterCat;
    return matchSearch && matchCat;
  });

  const downloadBook = async (b: Book) => {
    const { data, error } = await supabase.storage.from('books').createSignedUrl(b.file_path, 3600);
    if (error || !data) {
      alert('Kitobni yuklab bo\'lmadi. Iltimos qayta urinib ko\'ring.');
      return;
    }
    window.open(data.signedUrl, '_blank');
    if (user) await logActivity('kitob', `${b.title} — mutolaa qilindi`);
  };

  if (loading) return <div className="max-w-5xl mx-auto px-4 py-20 text-slate-500">Yuklanmoqda…</div>;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <button onClick={onBack} className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-100 mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Bosh sahifaga
      </button>

      <div className="rounded-2xl p-7 mb-8 text-white bg-gradient-to-r from-indigo-900 via-purple-900 to-slate-900 border border-slate-700/60 shadow-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur-sm text-sm font-medium mb-4">
          <BookOpen className="w-4 h-4" /> Raqamli Kutubxona
        </div>
        <h1 className="text-3xl font-bold mb-2">Raqamli Kutubxona</h1>
        <p className="opacity-90 max-w-2xl">Huquqshunoslik, darsliklar, audio-kitoblar va IIV maxsus adabiyotlar. Kitobni tanlang va o'qishni boshlang.</p>
      </div>

      {/* Search + categories */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-3 text-slate-500 w-4 h-4" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Kitob qidirish..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl text-sm glass text-slate-100 border border-slate-700 focus:outline-none focus:border-indigo-500"
          />
        </div>
        {categories.length > 0 && (
          <select value={filterCat} onChange={(e) => setFilterCat(e.target.value)} className="px-3.5 py-2.5 rounded-xl text-sm glass text-slate-200 border border-slate-700 focus:outline-none">
            <option value="">Barcha kategoriyalar</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}
      </div>

      {/* Add category (for logged-in users) */}
      {user && (
        <div className="mb-6 glass rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-2 flex items-center gap-1.5 text-slate-200"><FolderPlus className="w-4 h-4" /> Yangi kategoriya qo'shish</h3>
          <div className="flex gap-2">
            <input type="text" value={newCat} onChange={(e) => setNewCat(e.target.value)} placeholder="Masalan: Huquq, Darslik..." className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-indigo-500 focus:outline-none text-sm text-slate-100" />
            <button onClick={addCategory} className="px-4 py-2.5 rounded-xl text-white text-sm font-semibold inline-flex items-center gap-2 shrink-0 bg-indigo-600 hover:bg-indigo-500">
              <FolderPlus className="w-4 h-4" /> Qo'shish
            </button>
          </div>
          {categories.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {categories.map((c) => <span key={c.id} className="px-2.5 py-1 rounded-lg bg-slate-800/60 text-xs text-slate-400">{c.name}</span>)}
            </div>
          )}
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="text-center py-16 text-slate-500">
          <BookOpen className="w-14 h-14 mx-auto mb-3 opacity-30" />
          <p>{search || filterCat ? 'Qidiruv bo\'yicha kitob topilmadi.' : 'Hozircha kitoblar yo\'q. Admin kitob yuklashi mumkin.'}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {filtered.map((b) => {
            const Icon = CATEGORY_ICONS[b.subject_title] ?? (b.is_audio ? Headphones : BookText);
            return (
              <div key={b.id} className="glass rounded-2xl p-5 flex flex-col justify-between hover:border-indigo-500/40 transition-all">
                <div>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3 bg-indigo-500/20 text-indigo-400">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-sm mb-1 text-white line-clamp-2">{b.title}</h3>
                  {b.author && <span className="text-xs text-slate-400 block mb-1">{b.author}</span>}
                  <span className="text-[10px] text-slate-500 block mb-3">{b.subject_title} · {b.file_type?.toUpperCase()}{b.is_audio ? ' · Audio' : ''}</span>
                  {b.description && <p className="text-xs text-slate-400 line-clamp-2 mb-3">{b.description}</p>}
                </div>
                {b.is_audio ? (
                  <button
                    onClick={() => setPlayingBook(b)}
                    className="w-full py-2 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-1.5 bg-indigo-600/20 text-indigo-400 hover:bg-indigo-600/30 transition"
                  >
                    <Headphones className="w-3.5 h-3.5" /> Tinglash
                  </button>
                ) : (
                  <button
                    onClick={() => downloadBook(b)}
                    className="w-full py-2 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-1.5 bg-blue-600/20 text-blue-400 hover:bg-blue-600/30 transition"
                  >
                    <Download className="w-3.5 h-3.5" /> Mutolaa qilish
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {playingBook && <AudioBookPlayer book={playingBook} onClose={() => setPlayingBook(null)} />}
      {subjects.length === 0 && null}
    </div>
  );
}

function AudioBookPlayer({ book, onClose }: { book: Book; onClose: () => void }) {
  const { user } = useAuth();
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [url, setUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [rate, setRate] = useState(1);
  const [bookmarked, setBookmarked] = useState(false);

  useEffect(() => {
    (async () => {
      if (book.is_audio && book.audio_path) {
        const { data, error } = await supabase.storage.from('audio-files').createSignedUrl(book.audio_path, 3600);
        if (error || !data) { setError('Audio faylni yuklab bo\'lmadi.'); setLoading(false); return; }
        setUrl(data.signedUrl);
      }
      if (user) {
        const key = `bookmark_${user.id}_${book.id}`;
        setBookmarked(!!localStorage.getItem(key));
      }
      setLoading(false);
      if (user) await logActivity('kitob', `${book.title} — audio kitob tinglandi`);
    })();
  }, [book, user]);

  const toggle = () => {
    if (!audioRef.current) return;
    if (playing) { audioRef.current.pause(); setPlaying(false); }
    else { audioRef.current.play(); setPlaying(true); }
  };

  const changeRate = () => {
    const rates = [0.75, 1, 1.25, 1.5, 2];
    const idx = rates.indexOf(rate);
    const next = rates[(idx + 1) % rates.length];
    setRate(next);
    if (audioRef.current) audioRef.current.playbackRate = next;
  };

  const toggleBookmark = () => {
    if (!user) return;
    const key = `bookmark_${user.id}_${book.id}`;
    if (bookmarked) { localStorage.removeItem(key); setBookmarked(false); }
    else { localStorage.setItem(key, new Date().toISOString()); setBookmarked(true); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass-strong rounded-2xl p-6 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold flex items-center gap-2 text-white"><Headphones className="w-5 h-5 text-blue-400" /> Audio kitob</h3>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg"><X className="w-5 h-5" /></button>
        </div>
        <div className="text-center mb-4">
          <div className="w-20 h-20 rounded-2xl mx-auto mb-3 flex items-center justify-center bg-blue-500/20 text-blue-400">
            <Headphones className="w-10 h-10" />
          </div>
          <h4 className="font-semibold text-white">{book.title}</h4>
          {book.author && <p className="text-sm text-slate-400">{book.author}</p>}
        </div>
        {loading ? (
          <div className="text-center py-6 text-slate-400">Yuklanmoqda…</div>
        ) : error ? (
          <div className="text-center py-6 text-red-400 text-sm">{error}</div>
        ) : (
          <div className="space-y-3">
            <audio ref={audioRef} src={url ?? undefined} onEnded={() => setPlaying(false)} className="hidden" />
            <div className="flex items-center justify-center gap-4">
              <button onClick={toggleBookmark} className={`w-10 h-10 rounded-full flex items-center justify-center transition ${bookmarked ? 'text-amber-400 bg-amber-500/20' : 'text-slate-400 bg-slate-800/60'}`} title="Saqlash">
                <BookText className="w-5 h-5" />
              </button>
              <button onClick={toggle} className="w-14 h-14 rounded-full text-white flex items-center justify-center hover:opacity-90 transition-opacity bg-blue-600">
                {playing ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
              </button>
              <button onClick={changeRate} className="px-3 py-2 rounded-lg text-sm font-medium text-slate-200 bg-slate-800/60 hover:bg-slate-700 min-w-[60px]" title="Tezlik">
                {rate}x
              </button>
            </div>
            <p className="text-xs text-slate-400 text-center">{playing ? 'Ijro etilmoqda…' : 'Tinglashni boshlash uchun bosing'}</p>
          </div>
        )}
      </div>
    </div>
  );
}
