import { useEffect, useState } from 'react';
import { ArrowLeft, Video, PlayCircle, Clock, CheckCircle2, BookOpen, StickyNote, Save, Download, Sparkles, ChevronRight } from 'lucide-react';
import { supabase, VideoLesson, VideoProgress, Subject, TestFile } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';

type Note = { video_id: string; text: string; updated: string };

export default function Darsxona({ onBack, onOpenAI }: { onBack: () => void; onOpenAI: () => void }) {
  const { user } = useAuth();
  const [videos, setVideos] = useState<VideoLesson[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [progress, setProgress] = useState<Record<string, VideoProgress>>({});
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [activeVideo, setActiveVideo] = useState<VideoLesson | null>(null);
  const [noteText, setNoteText] = useState('');
  const [activeSubject, setActiveSubject] = useState<string>('Barchasi');
  const [testFiles, setTestFiles] = useState<TestFile[]>([]);

  useEffect(() => {
    (async () => {
      const [{ data: vids }, { data: subs }] = await Promise.all([
        supabase.from('video_lessons').select('*').order('sort_order').order('created_at'),
        supabase.from('subjects').select('*').order('sort_order'),
      ]);
      const vidArr = (vids as VideoLesson[]) ?? [];
      setVideos(vidArr);
      setSubjects((subs as Subject[]) ?? []);
      if (user) {
        const { data: pg } = await supabase.from('video_progress').select('*').eq('user_id', user.id);
        const pMap: Record<string, VideoProgress> = {};
        (pg as VideoProgress[])?.forEach((p) => { pMap[p.video_id] = p; });
        setProgress(pMap);
      }
      const { data: tf } = await supabase.from('test_files').select('*').order('created_at', { ascending: false }).limit(5);
      setTestFiles((tf as TestFile[]) ?? []);
      setLoading(false);
    })();
  }, [user]);

  const loadNotes = (vid: string) => {
    if (!user) return;
    const key = `darsxona_notes_${user.id}_${vid}`;
    const stored = localStorage.getItem(key);
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as Note;
        setNoteText(parsed.text);
        setNotes((n) => ({ ...n, [vid]: parsed.text }));
        return;
      } catch { /* ignore */ }
    }
    setNoteText('');
  };

  const saveNote = () => {
    if (!user || !activeVideo) return;
    const key = `darsxona_notes_${user.id}_${activeVideo.id}`;
    const note: Note = { video_id: activeVideo.id, text: noteText, updated: new Date().toISOString() };
    localStorage.setItem(key, JSON.stringify(note));
    setNotes((n) => ({ ...n, [activeVideo.id]: noteText }));
  };

  const fmtDur = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

  const markComplete = async (v: VideoLesson) => {
    if (!user) return;
    await supabase.from('video_progress').upsert({
      user_id: user.id, video_id: v.id, watched_seconds: v.duration_seconds, completed: true, updated_at: new Date().toISOString(),
    }, { onConflict: 'user_id,video_id' });
    const { data: pg } = await supabase.from('video_progress').select('*').eq('user_id', user.id);
    const pMap: Record<string, VideoProgress> = {};
    (pg as VideoProgress[])?.forEach((p) => { pMap[p.video_id] = p; });
    setProgress(pMap);
  };

  const downloadFile = async (f: TestFile) => {
    const { data } = await supabase.storage.from('test-files').createSignedUrl(f.file_path, 3600);
    if (data) window.open(data.signedUrl, '_blank');
  };

  if (loading) return <div className="max-w-5xl mx-auto px-4 py-20 text-slate-500">Yuklanmoqda…</div>;

  const completedCount = Object.values(progress).filter((p) => p.completed).length;
  const totalCount = videos.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const filteredVideos = activeSubject === 'Barchasi'
    ? videos
    : videos.filter((v) => v.category === activeSubject || v.category.toLowerCase().includes(activeSubject.toLowerCase()));

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <button onClick={onBack} className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-100 mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Bosh sahifaga
      </button>

      <div className="rounded-2xl p-7 mb-8 text-white bg-gradient-to-r from-indigo-900 via-purple-900 to-slate-900 border border-slate-700/60 shadow-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur-sm text-sm font-medium mb-4">
          <BookOpen className="w-4 h-4" /> Darsxona — Faol O'rganish Markazi
        </div>
        <h1 className="text-3xl font-bold mb-2">Darsxona Workspace</h1>
        <p className="opacity-90 max-w-2xl">Video darslarni tomosha qiling, eslatmalar yarating, fayllar yuklab oling va AI ga savol bering — barchasi bir joyda.</p>
        <div className="mt-6 grid grid-cols-3 gap-4 max-w-md">
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{totalCount}</div>
            <div className="text-xs text-slate-300">Jami darslar</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">{completedCount}</div>
            <div className="text-xs text-slate-300">Yakunlangan</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400">{progressPercent}%</div>
            <div className="text-xs text-slate-300">Progress</div>
          </div>
        </div>
      </div>

      {/* Subject filter */}
      <div className="flex flex-wrap gap-2 mb-6">
        <button onClick={() => setActiveSubject('Barchasi')}
          className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${activeSubject === 'Barchasi' ? 'bg-blue-600 text-white' : 'glass text-slate-300 hover:border-slate-600'}`}>
          Barchasi
        </button>
        {subjects.map((s) => (
          <button key={s.id} onClick={() => setActiveSubject(s.title)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${activeSubject === s.title ? 'bg-blue-600 text-white' : 'glass text-slate-300 hover:border-slate-600'}`}>
            {s.title}
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left: video list */}
        <div className="lg:col-span-1 space-y-3 max-h-[600px] overflow-y-auto pr-1">
          <h2 className="text-sm font-semibold text-slate-200 mb-1 flex items-center gap-2"><Video className="w-4 h-4 text-blue-400" /> Darslar ro'yxati</h2>
          {filteredVideos.map((v) => {
            const pg = progress[v.id];
            const isActive = activeVideo?.id === v.id;
            return (
              <button key={v.id} onClick={() => { setActiveVideo(v); loadNotes(v.id); }}
                className={`w-full text-left glass rounded-xl p-3 transition-all ${isActive ? 'border-blue-500/60 bg-blue-600/10' : 'hover:border-slate-600'}`}>
                <div className="flex items-start gap-2.5">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-slate-800">
                    {pg?.completed ? <CheckCircle2 className="w-5 h-5 text-green-400" /> : <PlayCircle className="w-5 h-5 text-blue-400" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-sm text-white line-clamp-2">{v.title}</h3>
                    <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-2">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {fmtDur(v.duration_seconds)}</span>
                      <span className="text-blue-400">{v.category}</span>
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
          {filteredVideos.length === 0 && <p className="text-sm text-slate-500 text-center py-8">Bu kategoriyada darslar yo'q.</p>}
        </div>

        {/* Right: active lesson area */}
        <div className="lg:col-span-2 space-y-6">
          {activeVideo ? (
            <>
              <div className="glass rounded-2xl overflow-hidden">
                <div className="aspect-video bg-black">
                  <iframe src={activeVideo.video_url} className="w-full h-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
                </div>
                <div className="p-5">
                  <h2 className="text-xl font-bold text-white mb-1">{activeVideo.title}</h2>
                  {activeVideo.description && <p className="text-sm text-slate-400 mb-3">{activeVideo.description}</p>}
                  <div className="flex items-center gap-3 text-xs text-slate-400 mb-4">
                    <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {fmtDur(activeVideo.duration_seconds)}</span>
                    <span className="text-blue-400">{activeVideo.category}</span>
                  </div>
                  {user && (
                    <button onClick={() => markComplete(activeVideo)} className="px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 inline-flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" /> Darsni yakunlash
                    </button>
                  )}
                </div>
              </div>

              {/* Notes panel */}
              {user && (
                <div className="glass rounded-2xl p-5">
                  <h3 className="font-semibold text-white mb-3 flex items-center gap-2"><StickyNote className="w-4 h-4 text-blue-400" /> Eslatmalar</h3>
                  <textarea value={noteText} onChange={(e) => setNoteText(e.target.value)} rows={5}
                    placeholder="Bu dars uchun eslatmalaringizni shu yerga yozing..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100 resize-y" />
                  <button onClick={saveNote} className="mt-2 px-4 py-2 rounded-xl text-sm font-medium text-white bg-blue-600 hover:bg-blue-500 inline-flex items-center gap-2">
                    <Save className="w-4 h-4" /> Saqlash
                  </button>
                  {notes[activeVideo.id] && <p className="text-xs text-green-400 mt-2">Eslatma saqlangan</p>}
                </div>
              )}

              {/* Resources */}
              {testFiles.length > 0 && (
                <div className="glass rounded-2xl p-5">
                  <h3 className="font-semibold text-white mb-3 flex items-center gap-2"><Download className="w-4 h-4 text-blue-400" /> Resurslar</h3>
                  <div className="space-y-2">
                    {testFiles.map((f) => (
                      <button key={f.id} onClick={() => downloadFile(f)} className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-slate-800/40 hover:bg-slate-800/60 text-left transition">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-blue-500/20 text-blue-400 shrink-0"><Download className="w-4 h-4" /></div>
                        <span className="text-sm text-slate-200 truncate">{f.title}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* AI Q&A shortcut */}
              <button onClick={onOpenAI} className="w-full glass rounded-2xl p-5 hover:border-blue-500/40 transition-all text-left">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 text-white flex items-center justify-center"><Sparkles className="w-5 h-5" /></div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-white">AI ga savol berish</h3>
                    <p className="text-sm text-slate-400">Bu dars bo'yicha tushunmagannlaringizni AI dan so'rang</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-500" />
                </div>
              </button>
            </>
          ) : (
            <div className="glass rounded-2xl p-12 text-center">
              <PlayCircle className="w-16 h-16 text-slate-700 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Darsni tanlang</h3>
              <p className="text-sm text-slate-500">Chap tomondagi ro'yxatdan darsni tanlab, tomosha qilishni boshlang.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
