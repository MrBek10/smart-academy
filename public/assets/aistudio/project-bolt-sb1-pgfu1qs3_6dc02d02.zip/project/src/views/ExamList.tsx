import { useEffect, useState } from 'react';
import { ArrowLeft, GraduationCap, Clock, ChevronRight, BookOpen, Award, Plus, Building2, FileBadge } from 'lucide-react';
import { supabase, Exam, Subject, ExamResult, ExamType } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';

type PanelKey = 'dtm' | 'milliy_sertifikat' | 'mavzuviy';

const PANELS: { key: PanelKey; label: string; icon: typeof BookOpen; desc: string }[] = [
  { key: 'dtm', label: 'DTM', icon: Building2, desc: "Davlat Test Markazi imtihonlari simulyatori" },
  { key: 'milliy_sertifikat', label: 'Milliy Sertifikat', icon: FileBadge, desc: "Milliy sertifikat imtihonlari (189 ball tizimi)" },
  { key: 'mavzuviy', label: 'Mavzuviy', icon: BookOpen, desc: "Mavzulashtirilgan tekshiruv testlari" },
];

export default function ExamList({ onOpenExam, onBack, onOpenAdmin, isAdmin = false }: { onOpenExam: (id: string) => void; onBack: () => void; onOpenAdmin?: () => void; isAdmin?: boolean }) {
  const { user } = useAuth();
  const { profile } = useAuth();
  const role = profile?.role ?? 'guest';
  const canManage = role === 'admin' || role === 'creator';
  const [exams, setExams] = useState<(Exam & { subject_title: string; subject_color: string })[]>([]);
  const [results, setResults] = useState<Record<string, ExamResult>>({});
  const [loading, setLoading] = useState(true);
  const [panel, setPanel] = useState<PanelKey>('dtm');

  useEffect(() => {
    (async () => {
      const { data: exs } = await supabase.from('exams').select('*').order('created_at', { ascending: false });
      const exsArr = (exs as Exam[]) ?? [];
      const subjectIds = [...new Set(exsArr.map((e) => e.subject_id))];
      const { data: subs } = await supabase.from('subjects').select('*').in('id', subjectIds.length ? subjectIds : ['00000000-0000-0000-0000-000000000000']);
      const subMap = new Map<string, Subject>((subs as Subject[])?.map((s) => [s.id, s]) ?? []);

      const enriched = exsArr.map((e) => {
        const s = subMap.get(e.subject_id);
        return { ...e, subject_title: s?.title ?? 'Umumiy', subject_color: s?.color ?? '#0f766e' };
      });
      setExams(enriched);

      if (user) {
        const { data: rs } = await supabase.from('exam_results').select('*').eq('user_id', user.id);
        const rMap: Record<string, ExamResult> = {};
        (rs as ExamResult[])?.forEach((r) => { rMap[r.exam_id] = r; });
        setResults(rMap);
      }
      setLoading(false);
    })();
  }, [user]);

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-20 text-slate-500">Yuklanmoqda…</div>;

  const primary = 'var(--theme-primary, #0f766e)';
  const accent = 'var(--theme-accent, #f59e0b)';

  const panelExams = exams.filter((e) => (e.exam_type ?? 'mavzuviy') === panel);
  const grouped: Record<string, typeof panelExams> = {};
  panelExams.forEach((e) => {
    const key = e.subject_title;
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(e);
  });

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <button onClick={onBack} className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-100 mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Bosh sahifaga
      </button>

      <div className="rounded-2xl p-7 mb-8 text-white bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 border border-slate-700/60 shadow-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur-sm text-sm font-medium mb-4">
          <Award className="w-4 h-4" /> Imtihon Xonasi
        </div>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-2">Imtihon Xonasi</h1>
            <p className="opacity-90 max-w-2xl">DTM, Milliy Sertifikat va Mavzuviy imtihonlarni topshiring. Har bir imtihon yakunida taxminiy sertifikat ballingiz hisoblanadi.</p>
          </div>
          {canManage && onOpenAdmin && (
            <button onClick={onOpenAdmin} className="shrink-0 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-semibold border border-emerald-400/30 transition inline-flex items-center gap-2">
              <Plus className="w-4 h-4" /> Yangi Test qo'shish
            </button>
          )}
        </div>
      </div>

      {/* 3-panel tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-8">
        {PANELS.map((p) => {
          const active = panel === p.key;
          const count = exams.filter((e) => (e.exam_type ?? 'mavzuviy') === p.key).length;
          return (
            <button
              key={p.key}
              onClick={() => setPanel(p.key)}
              className={`p-5 rounded-2xl border text-left transition-all ${active ? 'border-transparent text-white shadow-lg' : 'glass text-slate-300 hover:border-slate-600'}`}
              style={active ? { background: 'linear-gradient(to right, #2563eb, #6366f1)' } : undefined}
            >
              <div className="flex items-center gap-3 mb-2">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${active ? 'bg-white/20' : ''}`} style={!active ? { background: 'rgba(99,102,241,0.15)', color: '#818cf8' } : undefined}>
                  <p.icon className="w-5 h-5" />
                </div>
                <span className="font-bold">{p.label}</span>
                <span className={`ml-auto text-xs font-semibold px-2 py-0.5 rounded-full ${active ? 'bg-white/20' : 'bg-slate-800 text-slate-400'}`}>{count}</span>
              </div>
              <p className={`text-xs ${active ? 'opacity-90' : 'text-slate-500'}`}>{p.desc}</p>
            </button>
          );
        })}
      </div>

      {panelExams.length === 0 ? (
        <div className="text-center py-16 text-slate-500">
          <GraduationCap className="w-14 h-14 mx-auto mb-3 opacity-30" />
          <p>Bu panelda hozircha imtihonlar yo'q.{canManage ? ' Admin panel orqali qo\'shing.' : ''}</p>
        </div>
      ) : (
        <div className="space-y-8">
          {Object.entries(grouped).map(([subj, exs]) => (
            <div key={subj}>
              <h2 className="text-lg font-bold mb-3 flex items-center gap-2 text-white">
                <BookOpen className="w-5 h-5" style={{ color: exs[0].subject_color }} /> {subj}
              </h2>
              <div className="space-y-3">
                {exs.map((e) => {
                  const r = results[e.id];
                  return (
                    <button
                      key={e.id}
                      onClick={() => onOpenExam(e.id)}
                      className="w-full flex items-center gap-3 p-5 glass rounded-2xl hover:border-slate-600 transition text-left group"
                    >
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ background: `color-mix(in srgb, ${e.subject_color} 20%, transparent)`, color: e.subject_color }}>
                        <GraduationCap className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-white">{e.title}</h3>
                        <p className="text-sm text-slate-400 flex items-center gap-1.5 mt-0.5">
                          <Clock className="w-3.5 h-3.5" /> {e.duration_minutes} daqiqa
                        </p>
                      </div>
                      {r && (
                        <div className="text-right">
                          <div className="text-xl font-bold" style={{ color: r.percent >= 60 ? '#4ade80' : '#fbbf24' }}>{r.percent}%</div>
                          <div className="text-xs text-slate-500">{r.cert_score} ball</div>
                        </div>
                      )}
                      <ChevronRight className="w-5 h-5 text-slate-600 group-hover:translate-x-1 transition-transform shrink-0" />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
