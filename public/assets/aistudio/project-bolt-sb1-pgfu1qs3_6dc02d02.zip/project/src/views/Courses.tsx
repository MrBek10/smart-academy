import { useState, useEffect } from 'react';
import { ArrowLeft, GraduationCap, Clock, Award, ChevronRight, Plus, X } from 'lucide-react';
import { supabase, Course } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';

export default function Courses({ onBack, onOpenCourse }: { onBack: () => void; onOpenCourse: (id: string) => void }) {
  const { profile } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [enrolledIds, setEnrolledIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const isAdmin = profile?.role === 'admin' || profile?.role === 'creator';

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('courses').select('*').eq('is_published', true).order('created_at', { ascending: false });
      setCourses((data as Course[]) ?? []);
      const { data: user } = await supabase.auth.getUser();
      if (user.user) {
        const { data: ens } = await supabase.from('course_enrollments').select('course_id').eq('user_id', user.user.id);
        setEnrolledIds(((ens as { course_id: string }[]) ?? []).map((e) => e.course_id));
      }
      setLoading(false);
    })();
  }, []);

  const levelLabels: Record<string, string> = { Boshlangich: "Boshlang'ich", Orta: "O'rta", Yuqori: 'Yuqori' };
  const fmtPrice = (p: number) => new Intl.NumberFormat('uz-UZ').format(p) + " so'm";

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <button onClick={onBack} className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-100 mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Bosh sahifaga
      </button>

      <div className="rounded-2xl p-7 mb-8 text-white bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 border border-slate-700/60 shadow-2xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur-sm text-sm font-medium mb-4">
              <GraduationCap className="w-4 h-4" /> Kurslar
            </div>
            <h1 className="text-3xl font-bold mb-2">Kurslar Katalogi</h1>
            <p className="opacity-90 max-w-2xl">O'zingerizga mos kursni tanlang va yoziling. Har bir kurs uchun dars dasturi, o'qituvchi va narx mavjud.</p>
          </div>
          {isAdmin && (
            <button onClick={() => setShowAdd(!showAdd)} className="shrink-0 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-semibold text-sm flex items-center gap-2">
              {showAdd ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />} {showAdd ? 'Bekor' : "Kurs qo'shish"}
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="text-slate-500 text-center py-16">Yuklanmoqda...</div>
      ) : courses.length === 0 ? (
        <div className="text-center py-16 text-slate-500">
          <GraduationCap className="w-14 h-14 mx-auto mb-3 opacity-30" />
          <p>Hozircha kurslar yo'q.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {courses.map((c) => {
            const enrolled = enrolledIds.includes(c.id);
            return (
              <button key={c.id} onClick={() => onOpenCourse(c.id)} className="group glass rounded-2xl p-6 text-left hover:border-blue-500/40 hover:-translate-y-0.5 transition-all">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 bg-blue-500/20 text-blue-400 group-hover:scale-110 transition-transform">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <span className="text-[10px] text-blue-400 font-semibold uppercase tracking-wider">{c.category ?? 'Umumiy'}</span>
                <h3 className="font-bold text-lg mb-1.5 text-white mt-1">{c.title}</h3>
                <p className="text-sm text-slate-400 line-clamp-2">{c.description ?? ''}</p>
                <div className="flex flex-wrap gap-3 mt-4 text-xs text-slate-400">
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {c.duration_hours} soat</span>
                  <span className="flex items-center gap-1"><Award className="w-3 h-3" /> {levelLabels[c.level]}</span>
                </div>
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-700/50">
                  <span className="font-bold text-white">{fmtPrice(c.price)}</span>
                  {enrolled ? (
                    <span className="text-xs text-green-400 font-semibold">Yozilgan</span>
                  ) : (
                    <span className="text-sm font-medium text-blue-400 inline-flex items-center gap-1">Batafsil <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" /></span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {showAdd && isAdmin && <AddCourseForm onDone={() => { setShowAdd(false); window.location.reload(); }} />}
    </div>
  );
}

function AddCourseForm({ onDone }: { onDone: () => void }) {
  const [form, setForm] = useState({ title: '', description: '', instructor_name: '', price: '0', duration_hours: '0', level: 'Boshlangich', category: '' });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!form.title.trim()) return;
    setSaving(true);
    await supabase.from('courses').insert({
      title: form.title, description: form.description, instructor_name: form.instructor_name || 'Admin',
      price: parseFloat(form.price) || 0, duration_hours: parseInt(form.duration_hours) || 0,
      level: form.level, category: form.category || null,
    });
    setSaving(false);
    onDone();
  };

  return (
    <div className="glass rounded-2xl p-5 mt-6 space-y-3">
      <h3 className="font-bold text-white mb-2">Yangi kurs qo'shish</h3>
      <input type="text" placeholder="Kurs nomi" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100" />
      <textarea placeholder="Tavsif" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100" />
      <div className="grid sm:grid-cols-2 gap-3">
        <input type="text" placeholder="O'qituvchi" value={form.instructor_name} onChange={(e) => setForm({ ...form, instructor_name: e.target.value })} className="px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100" />
        <input type="text" placeholder="Kategoriya" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100" />
        <input type="number" placeholder="Narx (so'm)" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100" />
        <input type="number" placeholder="Davomiyligi (soat)" value={form.duration_hours} onChange={(e) => setForm({ ...form, duration_hours: e.target.value })} className="px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100" />
      </div>
      <select value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value })} className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100">
        <option value="Boshlangich">Boshlang'ich</option>
        <option value="Orta">O'rta</option>
        <option value="Yuqori">Yuqori</option>
      </select>
      <button onClick={save} disabled={saving} className="px-5 py-2.5 rounded-xl text-white text-sm font-semibold bg-blue-600 hover:bg-blue-500 disabled:opacity-50">Saqlash</button>
    </div>
  );
}
