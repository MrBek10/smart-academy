import { useRef, useState, useEffect } from 'react';
import { ArrowLeft, Send, Sparkles, Bot, User as UserIcon, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

type ChatMsg = { role: 'user' | 'ai'; text: string };

export default function AIAssistant({ onBack }: { onBack: () => void }) {
  const [chat, setChat] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [chat, thinking]);

  const send = async () => {
    const q = input.trim();
    if (!q || thinking) return;
    setInput('');
    setChat((c) => [...c, { role: 'user', text: q }]);
    setThinking(true);

    let ans: string;
    try {
      const { data: fnData, error: fnErr } = await supabase.functions.invoke('ai-tutor', {
        body: { question: q, lessonContent: undefined, topicTitle: undefined },
      });
      if (!fnErr && fnData?.answer) {
        ans = fnData.answer as string;
      } else {
        // Fallback to Wikipedia
        try {
          const wikiUrl = `https://uz.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q)}`;
          const res = await fetch(wikiUrl);
          if (res.ok) {
            const data = await res.json();
            if (data.extract) {
              ans = data.extract;
              if (data.content_urls?.desktop?.page) ans += `\n\nManba: ${data.content_urls.desktop.page}`;
            } else {
              ans = "Bu mavzu bo'yicha ma'lumot topilmadi. Iltimos, savolni aniqlashtiring.";
            }
          } else {
            ans = "Internetga ulanishda muammo. Iltimos qaytadan urinib ko'ring.";
          }
        } catch {
          ans = "Internetga ulanishda xatolik. Iltimos qaytadan urinib ko'ring.";
        }
      }
    } catch {
      ans = "So'rovnoma xatoligi. Iltimos qaytadan urinib ko'ring.";
    }

    setChat((c) => [...c, { role: 'ai', text: ans }]);
    setThinking(false);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <button onClick={onBack} className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-100 mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Bosh sahifaga
      </button>

      <div className="rounded-2xl p-7 mb-6 text-white bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 border border-slate-700/60 shadow-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 backdrop-blur-sm text-sm font-medium mb-3">
          <Sparkles className="w-4 h-4" /> AI Yordamchi
        </div>
        <h1 className="text-2xl font-bold mb-1">AI Savol-Javob Moduli</h1>
        <p className="opacity-90 text-sm">Gemini AI yordamida istalgan savolingizga javob oling. Bilimingizni chuqurlashtiring.</p>
      </div>

      <div className="glass rounded-2xl flex flex-col h-[60vh]">
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
          {chat.length === 0 && (
            <div className="text-center text-slate-400 py-12">
              <Bot className="w-14 h-14 mx-auto mb-4 opacity-40" />
              <p className="font-medium">Salom! Men AI yordmchiman.</p>
              <p className="text-sm mt-1">Istalgan savolingizni bering — men sizga tushuntirib beraman.</p>
            </div>
          )}
          {chat.map((m, i) => (
            <div key={i} className={`flex gap-2 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${m.role === 'user' ? 'bg-slate-700' : 'bg-gradient-to-tr from-blue-600 to-indigo-500 text-white'}`}>
                {m.role === 'user' ? <UserIcon className="w-4 h-4 text-slate-200" /> : <Bot className="w-4 h-4" />}
              </div>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm whitespace-pre-wrap leading-relaxed ${m.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-800/60 text-slate-200'}`}>
                {m.text}
              </div>
            </div>
          ))}
          {thinking && (
            <div className="flex gap-2">
              <div className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-white bg-gradient-to-tr from-blue-600 to-indigo-500">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-slate-800/60 rounded-2xl px-4 py-2.5 text-sm text-slate-400 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" /> O'ylayapman...
              </div>
            </div>
          )}
        </div>

        <div className="p-3 border-t border-slate-700/50">
          <div className="flex gap-2">
            <input type="text" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()}
              placeholder="Savolingizni yozing..."
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100" />
            <button onClick={send} disabled={!input.trim() || thinking}
              className="px-4 rounded-xl text-white disabled:opacity-40 bg-blue-600 hover:bg-blue-500 transition">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
