import { useState } from 'react';
import { GraduationCap, Sparkles, BookOpen, Bot, Clock, Shield, ArrowRight, Eye } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useTheme } from '@/lib/theme';
import { supabase } from '@/lib/supabase';

export default function Landing({ onEnter }: { onEnter: () => void }) {
  const { enterGuest } = useAuth();
  const { globalTheme } = useTheme();
  const [showAuth, setShowAuth] = useState<'login' | 'signup' | null>(null);

  const features = [
    { icon: BookOpen, title: 'Virtual Dars Xonasi', desc: "Maktab doskasi ko'rinishidagi interaktiv darslar." },
    { icon: Bot, title: 'AI Repetitor', desc: 'Mavzuni tushunmasangiz, AI ga savol bering — sodda tushuntiradi.' },
    { icon: Clock, title: 'Imtihon Xonasi', desc: "Taymer va avtomatik baholash bilan imtihon topshiring." },
    { icon: Shield, title: 'Xavfsiz Rollar', desc: "Yaratuvchi, admin va o'quvchi rollari bilan himoyalangan tizim." },
  ];

  if (showAuth === 'login') return <Login onBack={() => setShowAuth(null)} onSuccess={onEnter} />;
  if (showAuth === 'signup') return <Signup onBack={() => setShowAuth(null)} onSuccess={onEnter} />;

  return (
    <div className="min-h-screen bg-slate-950">
      <header className="glass-strong border-b border-slate-700/50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-xl flex items-center justify-center text-white bg-gradient-to-tr from-blue-600 to-indigo-500">
              <GraduationCap className="w-5 h-5" />
            </span>
            <span className="font-bold text-lg text-white">{globalTheme?.site_name ?? 'Smart Academy'}</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={enterGuest} className="px-3.5 py-2 rounded-lg text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/60 inline-flex items-center gap-1.5">
              <Eye className="w-4 h-4" /> Mehmon
            </button>
            <button onClick={() => setShowAuth('login')} className="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500">
              Kirish
            </button>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden text-white bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, white 1px, transparent 1px), radial-gradient(circle at 80% 70%, white 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        <div className="relative max-w-6xl mx-auto px-4 py-24 text-center">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/15 backdrop-blur-sm text-sm font-medium mb-5">
            <Sparkles className="w-4 h-4" /> Sun'iy intellekt bilan boyitilgan ta'lim
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-tight mb-5">
            Bilim oling. <span className="opacity-80">Tushuning.</span> <span className="text-amber-400">Sinab ko'ring.</span>
          </h1>
          <p className="text-lg md:text-xl opacity-90 max-w-2xl mx-auto mb-8 leading-relaxed">
            Litseylar uchun zamonaviy raqamli ta'lim platformasi. Xavfsiz rollar, doska ko'rinishidagi darslar, AI repetitor va imtihon xonasi.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <button onClick={() => setShowAuth('signup')} className="px-6 py-3.5 rounded-xl bg-white text-slate-900 font-semibold inline-flex items-center gap-2 hover:bg-slate-100 transition-colors shadow-lg">
              Ro'yxatdan o'tish <ArrowRight className="w-4 h-4" />
            </button>
            <button onClick={enterGuest} className="px-6 py-3.5 rounded-xl bg-white/15 backdrop-blur-sm font-semibold border border-white/25 hover:bg-white/25 transition-colors inline-flex items-center gap-2">
              <Eye className="w-4 h-4" /> Mehmon sifatida ko'rish
            </button>
          </div>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((f) => (
            <div key={f.title} className="glass rounded-2xl p-6">
              <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-4 bg-blue-500/20 text-blue-400">
                <f.icon className="w-5 h-5" />
              </div>
              <h3 className="font-semibold mb-1.5 text-white">{f.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Login({ onBack, onSuccess }: { onBack: () => void; onSuccess: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { globalTheme } = useTheme();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);
    setLoading(true);
    const { error: err } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (err) { setError('Email yoki parol noto\'g\'ri.'); return; }
    onSuccess();
  };

  return <AuthCard title="Tizimga kirish" subtitle="Akkauntingizga kiring" onBack={onBack} email={email} password={password} setEmail={setEmail} setPassword={setPassword} loading={loading} error={error} submit={submit} ctaLabel="Kirish" siteName={globalTheme?.site_name} />;
}

function Signup({ onBack, onSuccess }: { onBack: () => void; onSuccess: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { globalTheme } = useTheme();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);
    if (password.length < 6) { setError('Parol kamida 6 belgidan iborat bo\'lishi kerak.'); return; }
    setLoading(true);
    const { error: err } = await supabase.auth.signUp({ email, password });
    setLoading(false);
    if (err) { setError(err.message.includes('already') ? 'Bu email allaqachon ro\'yxatdan o\'tgan.' : 'Ro\'yxatdan o\'tishda xato. Qaytadan urinib ko\'ring.'); return; }
    onSuccess();
  };

  return <AuthCard title="Ro'yxatdan o'tish" subtitle="Yangi akkaunt yarating" onBack={onBack} email={email} password={password} setEmail={setEmail} setPassword={setPassword} loading={loading} error={error} submit={submit} ctaLabel="Ro'yxatdan o'tish" siteName={globalTheme?.site_name} />;
}

function AuthCard({ title, subtitle, onBack, email, password, setEmail, setPassword, loading, error, submit, ctaLabel, siteName }: {
  title: string; subtitle: string; onBack: () => void;
  email: string; password: string; setEmail: (v: string) => void; setPassword: (v: string) => void;
  loading: boolean; error: string | null; submit: (e: React.FormEvent) => void; ctaLabel: string; siteName?: string;
}) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <span className="inline-flex w-12 h-12 rounded-2xl items-center justify-center text-white mb-3 bg-gradient-to-tr from-blue-600 to-indigo-500">
            <GraduationCap className="w-6 h-6" />
          </span>
          <h1 className="text-2xl font-bold text-white">{siteName ?? 'Smart Academy'}</h1>
          <p className="text-slate-400 text-sm mt-1">{subtitle}</p>
        </div>
        <form onSubmit={submit} className="glass rounded-2xl p-6 space-y-4">
          <h2 className="font-semibold text-lg text-white">{title}</h2>
          <div>
            <label className="text-sm font-medium text-slate-300 mb-1.5 block">Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100" />
          </div>
          <div>
            <label className="text-sm font-medium text-slate-300 mb-1.5 block">Parol</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100" />
          </div>
          {error && <div className="text-sm text-red-400 bg-red-500/10 px-3 py-2 rounded-lg">{error}</div>}
          <button type="submit" disabled={loading} className="w-full py-3 rounded-xl text-white font-semibold disabled:opacity-50 bg-blue-600 hover:bg-blue-500">
            {loading ? 'Kuting…' : ctaLabel}
          </button>
          <button type="button" onClick={onBack} className="w-full text-sm text-slate-400 hover:text-slate-100">Orqaga</button>
        </form>
      </div>
    </div>
  );
}
