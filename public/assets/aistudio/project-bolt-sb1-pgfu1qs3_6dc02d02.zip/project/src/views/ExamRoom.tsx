import { useEffect, useState } from 'react';
import { ArrowLeft, Clock, CheckCircle2, XCircle, Award, RotateCcw, ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase, Exam, ExamQuestion, ExamResult, CERT_MAX_SCORE, logActivity } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';

type AnswerMap = Record<string, 'a' | 'b' | 'c' | 'd' | null>;

export default function ExamRoom({ examId, onBack }: { examId: string; onBack: () => void }) {
  const { user } = useAuth();
  const [exam, setExam] = useState<Exam | null>(null);
  const [questions, setQuestions] = useState<ExamQuestion[]>([]);
  const [answers, setAnswers] = useState<AnswerMap>({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [savedResult, setSavedResult] = useState<ExamResult | null>(null);
  const [currentQ, setCurrentQ] = useState(0);

  useEffect(() => {
    (async () => {
      const { data: ex } = await supabase.from('exams').select('*').eq('id', examId).maybeSingle();
      const exObj = ex as Exam | null;
      setExam(exObj);
      const { data: qs } = await supabase.from('exam_questions').select('*').eq('exam_id', examId).order('created_at');
      const qsArr = (qs as ExamQuestion[]) ?? [];
      setQuestions(qsArr);
      setSecondsLeft((exObj?.duration_minutes ?? 10) * 60);
      const initial: AnswerMap = {};
      qsArr.forEach((q) => (initial[q.id] = null));
      setAnswers(initial);
      setLoading(false);
    })();
  }, [examId]);

  useEffect(() => {
    if (submitted || loading || secondsLeft <= 0) return;
    const t = setInterval(() => setSecondsLeft((s) => s - 1), 1000);
    return () => clearInterval(t);
  }, [submitted, loading, secondsLeft]);

  useEffect(() => {
    if (secondsLeft === 0 && !submitted && !loading && questions.length > 0) {
      finishExam();
    }
  }, [secondsLeft, submitted, loading, questions.length]);

  if (loading) return <div className="max-w-3xl mx-auto px-4 py-20 text-slate-500">Yuklanmoqda…</div>;
  if (!exam) return <div className="max-w-3xl mx-auto px-4 py-20 text-slate-300">Imtihon topilmadi.</div>;

  const answeredCount = Object.values(answers).filter(Boolean).length;
  const allAnswered = answeredCount === questions.length;

  const score = questions.reduce((acc, q) => acc + (answers[q.id] === q.correct_answer ? 1 : 0), 0);
  const percent = questions.length > 0 ? Math.round((score / questions.length) * 100) : 0;
  const passed = percent >= 60;
  const certScore = Math.round((percent / 100) * CERT_MAX_SCORE * 100) / 100;
  const certGrade = percent >= 85
    ? { label: 'A — Yuqori daraja', color: '#16a34a' }
    : percent >= 70
    ? { label: 'B — O\'rta daraja', color: '#d97706' }
    : { label: 'C — Past daraja', color: '#dc2626' };

  const fmt = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  const primary = 'var(--theme-primary, #0f766e)';

  const finishExam = async () => {
    setSubmitted(true);
    const totalSec = (exam?.duration_minutes ?? 10) * 60 - secondsLeft;
    if (user) {
      const { data } = await supabase.from('exam_results').upsert({
        user_id: user.id,
        exam_id: examId,
        score,
        total: questions.length,
        percent,
        cert_score: certScore,
      }, { onConflict: 'user_id,exam_id' }).select('*').maybeSingle();
      setSavedResult(data as ExamResult | null);
      await logActivity('imtihon', `${exam?.title} — ${score}/${questions.length} (${percent}%)`, totalSec);
    }
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-10">
        <div className="glass-strong rounded-3xl p-8 text-center">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-5 ${passed ? 'bg-green-500/20' : 'bg-amber-500/20'}`} style={passed ? {} : {}}>
            <Award className={`w-10 h-10 ${passed ? 'text-green-400' : 'text-amber-400'}`} />
          </div>
          <h1 className="text-2xl font-bold mb-1 text-white">Imtihon yakunlandi</h1>
          <p className="text-slate-400 mb-6">{exam.title}</p>

          <div className="text-5xl font-bold mb-2" style={{ color: passed ? '#4ade80' : '#fbbf24' }}>{percent}%</div>
          <p className="text-slate-300 mb-3">{score} / {questions.length} to'g'ri javob</p>

          {/* Milliy Sertifikat taxminiy balli */}
          <div className="glass rounded-2xl p-5 mb-8">
            <div className="flex items-center gap-2 mb-1.5 justify-center text-slate-300">
              <Award className="w-4 h-4" /> <span className="text-sm font-medium">Taxminiy Milliy Sertifikat balli</span>
            </div>
            <div className="text-4xl font-bold mb-1 text-blue-400">{certScore}</div>
            <div className="text-xs text-slate-500 mb-3">/ {CERT_MAX_SCORE} ball (maksimal)</div>
            <div className="inline-block px-4 py-1.5 rounded-full text-sm font-bold" style={{ background: certGrade.color, color: 'white' }}>
              {certGrade.label}
            </div>
            <div className="text-xs mt-3" style={{ color: passed ? '#4ade80' : '#fbbf24' }}>
              {passed ? 'Tabriklaymiz! Sertifikat uchun yetarli natija.' : 'Sertifikat uchun kamida 60% kerak. Yana urinib ko\'ring.'}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-8 text-sm">
            <div className="glass rounded-xl p-4">
              <div className="text-2xl font-bold text-white">{questions.length}</div>
              <div className="text-slate-400">Savollar</div>
            </div>
            <div className="glass rounded-xl p-4">
              <div className="text-2xl font-bold text-green-400">{score}</div>
              <div className="text-slate-400">To'g'ri</div>
            </div>
            <div className="glass rounded-xl p-4">
              <div className="text-2xl font-bold text-red-400">{questions.length - score}</div>
              <div className="text-slate-400">Noto'g'ri</div>
            </div>
          </div>

          <div className="text-left space-y-3 mb-8">
            {questions.map((q, i) => {
              const userAns = answers[q.id];
              const correct = userAns === q.correct_answer;
              return (
                <div key={q.id} className="glass rounded-xl p-4">
                  <div className="flex items-start gap-2 mb-2">
                    {correct ? <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0 mt-0.5" /> : <XCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />}
                    <div className="flex-1">
                      <div className="font-medium text-sm text-slate-100">{i + 1}. {q.question}</div>
                      {!correct && (
                        <div className="text-xs mt-1.5 space-y-0.5">
                          {userAns && <div className="text-red-400">Sizning javobingiz: {q[`option_${userAns}`]}</div>}
                          <div className="text-green-400">To'g'ri javob: {q[`option_${q.correct_answer}`]}</div>
                        </div>
                      )}
                      {q.explanation && <div className="text-xs text-slate-500 mt-1.5 italic">{q.explanation}</div>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <button onClick={onBack} className="px-6 py-3 rounded-xl text-white font-semibold inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500">
            <RotateCcw className="w-4 h-4" /> Bosh sahifaga
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <button onClick={onBack} className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-100 mb-5 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Imtihondan chiqish
      </button>

      <div className="glass-strong rounded-2xl p-5 mb-5 flex items-center justify-between sticky top-20 z-10">
        <div>
          <span className="inline-block px-2.5 py-1 rounded-full text-xs font-bold mb-1 bg-blue-500/20 text-blue-400">
            {answeredCount} / {questions.length} javob berildi
          </span>
          <h1 className="font-bold text-white">{exam.title}</h1>
        </div>
        <div className={`flex items-center gap-2 px-4 py-2 rounded-xl font-mono font-bold tabular-nums ${secondsLeft < 60 ? 'bg-red-500/20 text-red-400' : 'glass text-slate-200'}`}>
          <Clock className="w-4 h-4" /> {fmt(secondsLeft)}
        </div>
      </div>

      {/* Progress dots */}
      <div className="flex flex-wrap gap-1.5 mb-5">
        {questions.map((q, i) => {
          const answered = answers[q.id] !== null;
          const isCurrent = i === currentQ;
          return (
            <button
              key={q.id}
              onClick={() => setCurrentQ(i)}
              className={`w-8 h-8 rounded-lg text-xs font-bold transition-colors ${
                isCurrent ? 'text-white bg-blue-600' : answered ? 'bg-green-500/20 text-green-400' : 'glass text-slate-500'
              }`}
              style={isCurrent ? { background: primary } : undefined}
            >
              {i + 1}
            </button>
          );
        })}
      </div>

      {/* Current question (one at a time) */}
      {questions.length > 0 && (
        <div className="glass rounded-2xl p-6 mb-5">
          {(() => {
            const q = questions[currentQ];
            const opts: { key: 'a' | 'b' | 'c' | 'd'; text: string }[] = [
              { key: 'a', text: q.option_a },
              { key: 'b', text: q.option_b },
              { key: 'c', text: q.option_c },
              { key: 'd', text: q.option_d },
            ];
            return (
              <>
                <div className="flex gap-2 mb-4">
                  <span className="shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold bg-blue-500/20 text-blue-400">
                    {currentQ + 1}
                  </span>
                  <div className="flex-1">
                    <span className="text-xs font-semibold uppercase tracking-wider block mb-1 text-blue-400">
                      {currentQ + 1} / {questions.length} — Savol
                    </span>
                    <h3 className="font-semibold text-base md:text-lg pt-0.5 text-white">{q.question}</h3>
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-2.5">
                  {opts.map((o) => {
                    const selected = answers[q.id] === o.key;
                    return (
                      <button
                        key={o.key}
                        onClick={() => setAnswers((a) => ({ ...a, [q.id]: o.key }))}
                        className={`flex items-center gap-3 p-3.5 rounded-xl border text-left text-sm transition-colors ${
                          selected ? 'border-transparent text-white bg-blue-600' : 'glass text-slate-200 hover:border-slate-600'
                        }`}
                      >
                        <span className={`shrink-0 w-7 h-7 rounded-md flex items-center justify-center text-xs font-bold uppercase ${selected ? 'bg-white/25' : 'bg-slate-800'}`}>
                          {o.key}
                        </span>
                        <span className="flex-1">{o.text}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex justify-between items-center pt-4 mt-4 border-t border-slate-700/50">
                  <button
                    onClick={() => setCurrentQ((i) => Math.max(0, i - 1))}
                    disabled={currentQ === 0}
                    className="px-4 py-2 rounded-xl text-xs font-semibold glass text-slate-300 disabled:opacity-40 flex items-center gap-1"
                  >
                    <ChevronLeft className="w-4 h-4" /> Oldingi
                  </button>
                  {currentQ < questions.length - 1 ? (
                    <button
                      onClick={() => setCurrentQ((i) => Math.min(questions.length - 1, i + 1))}
                      className="px-6 py-2.5 rounded-xl text-xs font-bold text-white shadow transition flex items-center gap-1 bg-blue-600 hover:bg-blue-500"
                    >
                      Keyingi <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={finishExam}
                      disabled={!allAnswered}
                      className="px-6 py-2.5 rounded-xl text-xs font-bold text-white shadow transition disabled:opacity-40 flex items-center gap-1 bg-blue-600 hover:bg-blue-500"
                    >
                      Imtihonni yakunlash <CheckCircle2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </>
            );
          })()}
        </div>
      )}

      <div className="mt-2 flex items-center justify-between gap-3">
        <p className="text-sm text-slate-400">{answeredCount} / {questions.length} javob</p>
        <button
          onClick={finishExam}
          disabled={!allAnswered}
          className="px-6 py-3 rounded-xl text-white font-semibold disabled:opacity-40 transition-opacity bg-blue-600 hover:bg-blue-500"
        >
          Imtihonni yakunlash
        </button>
      </div>
    </div>
  );
}
