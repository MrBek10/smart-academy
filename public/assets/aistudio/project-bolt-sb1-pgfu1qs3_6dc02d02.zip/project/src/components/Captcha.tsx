import { useCallback, useEffect, useRef, useState } from 'react';
import { RefreshCw, ShieldCheck } from 'lucide-react';

type Mode = 'math' | 'text';

export default function Captcha({ onVerify, label = 'Tasdiqlang' }: { onVerify: (verified: boolean) => void; label?: string }) {
  const [mode] = useState<Mode>('math');
  const [a, setA] = useState(0);
  const [b, setB] = useState(0);
  const [answer, setAnswer] = useState('');
  const [verified, setVerified] = useState(false);
  const [error, setError] = useState(false);
  const [textCode, setTextCode] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const generate = useCallback(() => {
    setVerified(false);
    onVerify(false);
    setAnswer('');
    setError(false);
    if (mode === 'math') {
      setA(Math.floor(Math.random() * 9) + 1);
      setB(Math.floor(Math.random() * 9) + 1);
    } else {
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
      let code = '';
      for (let i = 0; i < 5; i++) code += chars[Math.floor(Math.random() * chars.length)];
      setTextCode(code);
    }
  }, [mode, onVerify]);

  useEffect(() => { generate(); }, [generate]);

  useEffect(() => {
    if (mode !== 'text' || !canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, 140, 50);
    const colors = ['#60a5fa', '#a78bfa', '#f472b6', '#fbbf24', '#34d399'];
    for (let i = 0; i < 6; i++) {
      ctx.strokeStyle = colors[Math.floor(Math.random() * colors.length)];
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(Math.random() * 140, Math.random() * 50);
      ctx.lineTo(Math.random() * 140, Math.random() * 50);
      ctx.stroke();
    }
    for (let i = 0; i < textCode.length; i++) {
      ctx.font = `${18 + Math.random() * 6}px sans-serif`;
      ctx.fillStyle = colors[Math.floor(Math.random() * colors.length)];
      const x = 12 + i * 24;
      const y = 32 + Math.random() * 6 - 3;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate((Math.random() - 0.5) * 0.5);
      ctx.fillText(textCode[i], 0, 0);
      ctx.restore();
    }
  }, [textCode, mode]);

  const check = () => {
    const correct = mode === 'math' ? a + b : textCode;
    if (answer.trim().toUpperCase() === String(correct)) {
      setVerified(true);
      setError(false);
      onVerify(true);
    } else {
      setError(true);
      onVerify(false);
      setTimeout(generate, 500);
    }
  };

  if (verified) {
    return (
      <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-green-500/20 border border-green-500/30 text-green-400 text-sm font-medium">
        <ShieldCheck className="w-4 h-4" /> Bot tekshiruvi o'tdi
      </div>
    );
  }

  return (
    <div className="glass rounded-xl p-3.5 space-y-2.5">
      <div className="flex items-center gap-2 text-sm font-medium text-slate-300">
        <ShieldCheck className="w-4 h-4 text-blue-400" /> {label}
      </div>
      {mode === 'math' ? (
        <div className="flex items-center gap-3">
          <span className="text-lg font-mono font-bold text-white tabular-nums">{a} + {b} =</span>
          <input
            type="text"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && check()}
            placeholder="Javob"
            className="w-20 px-3 py-2 rounded-lg bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100 text-center"
          />
          <button onClick={check} className="px-3 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-500">Tekshirish</button>
          <button onClick={generate} className="p-2 text-slate-400 hover:text-slate-100" title="Yangilash">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-3">
          <canvas ref={canvasRef} width={140} height={50} className="rounded-lg" />
          <input
            type="text"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && check()}
            placeholder="Kodni kiriting"
            className="w-28 px-3 py-2 rounded-lg bg-slate-800/60 border border-slate-700 focus:border-blue-500 outline-none text-sm text-slate-100 text-center"
          />
          <button onClick={check} className="px-3 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-500">Tekshirish</button>
          <button onClick={generate} className="p-2 text-slate-400 hover:text-slate-100" title="Yangilash">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      )}
      {error && <p className="text-xs text-red-400">Noto'g'ri javob. Iltimos, qaytadan urinib ko'ring.</p>}
    </div>
  );
}
